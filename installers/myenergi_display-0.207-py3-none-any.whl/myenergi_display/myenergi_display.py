#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Many thanks to Andy Twonk (https://github.com/twonk/MyEnergi-App-Api) for details the myenergi api
# used in this project.

import argparse
import os
import csv
import threading
import requests
import traceback

from requests.auth import HTTPDigestAuth
from queue import Queue
from time import time, sleep

from datetime import timedelta, datetime, timezone
import urllib.request
import json
from copy import deepcopy

from p3lib.pconfig import ConfigManager, ConfigAttrDetails

import plotly.graph_objects as go

from p3lib.uio import UIO
from p3lib.helper import logTraceBack
from p3lib.pconfig import DotConfigManager
from p3lib.boot_manager import BootManager
from p3lib.ngt import TabbedNiceGui, YesNoDialog

from nicegui import ui, html, app, run


class MyEnergi(object):
    """@brief An interface to MyEnergi products.
              This is not meant to be a comprehensive interface.
              It provides the functionality required by this application."""
    TANK_TOP = 1
    TANK_BOTTOM = 2
    DIRECTOR_URL = 'https://director.myenergi.net/'
    FALLBACK_BASE_URL = 'https://s18.myenergi.net/'     # Used if the director does not tell us which server to use
    ASN_HEADER = 'X_MYENERGI-asn'                       # Header in which the director returns the server name
    REQUEST_TIMEOUT_SECONDS = 30
    TOP_TANK_ID = 1
    BOTTOM_TANK_ID = 2
    TANK_1_BOOST_SCHEDULE_SLOT_ID = 14
    TANK_2_BOOST_SCHEDULE_SLOT_ID = 24
    VALID_EDDI_SLOT_ID_LIST = (11, 12, 13, TANK_1_BOOST_SCHEDULE_SLOT_ID, 21, 22, 23, TANK_2_BOOST_SCHEDULE_SLOT_ID)
    VALID_ZAPPI_SLOT_ID_LIST = (11, 12, 13, 14)
    ZAPPI_CHARG_MODE_FAST = 1
    ZAPPI_CHARGE_MODE_ECO = 2
    ZAPPI_CHARGE_MODE_ECO_PLUS = 3
    ZAPPI_CHARGE_MODE_STOPPED = 4

    ZAPPI_PST_EV_DISCONNECTED = 'A'
    ZAPPI_PST_EV_CONNECTED = 'B1'
    ZAPPI_PST_WAITING_FOR_EV = 'B2'
    ZAPPI_PST_EV_READY_TO_CHARGE = 'C1'
    ZAPPI_PST_EV_CHARGING = 'C2'
    ZAPPI_PST_FAULT = 'F'

    ZAPPI_STA_EVSE_READY = 1
    ZAPPI_STA_CONNECTED = 2
    ZAPPI_STA_CHARGING = 3
    ZAPPI_STA_WAITING = 4
    ZAPPI_STA_BOOSTING = 5

    def __init__(self, api_key, uio=None):
        """@brief Constuctor
           @param api_key Your myenergi API key.
                          You must create this on the myenergi web site.
                          See https://support.myenergi.com/hc/en-gb/articles/5069627351185-How-do-I-get-an-API-key for more information.
           @param uio An UIO instance."""
        self._api_key = api_key
        self._eddi_serial_number = None
        self._zappi_serial_number = None
        self._eddi_stats_dict = None
        self._zappi_stats_dict = None
        self._uio = uio
        self._lock = threading.Lock()
        self._base_url = None           # The myenergi server for this account. Found on first use.

    def set_eddi_serial_number(self, eddi_serial_number):
        """@brief set the eddi serial number.
           @param eddi_serial_number The serial number of the eddi unit of interest."""
        self._eddi_serial_number = eddi_serial_number

    def set_zappi_serial_number(self, zappi_serial_number):
        """@brief set the zappi serial number.
           @param zappi_serial_number The serial number of the zappi unit of interest."""
        self._zappi_serial_number = zappi_serial_number

    def _check_eddi_serial_number(self):
        """@brief Check that the eddi serial number has been set."""
        if self._eddi_serial_number is None:
            raise Exception("BUG: The eddi serial number has not been set.")

    def _check_zappi_serial_number(self):
        """@brief Check that the zappi serial number has been set."""
        if self._zappi_serial_number is None:
            raise Exception("BUG: The zappi serial number has not been set.")

    def get_stats(self):
        """@brief Get the stats of the eddi unit."""
        self._check_eddi_serial_number()
        url = "cgi-jstatus-*"
        return self._exec_api_cmd(url)

    def update_stats(self):
        """@brief update all the stats."""
        stats_list = self.get_stats()
        for stats_dict in stats_list:
            if 'eddi' in stats_dict:
                eddi_dict_list = stats_dict['eddi']
                for eddi_dict in eddi_dict_list:
                    if 'sno' in eddi_dict:
                        serial_number = eddi_dict['sno']
                        # Check the eddi serial number matches
                        if str(serial_number) == str(self._eddi_serial_number):
                            # Assign the eddi dict
                            self._eddi_stats_dict = eddi_dict

            elif 'zappi' in stats_dict:
                zappi_dict_list = stats_dict['zappi']
                for zappi_dict in zappi_dict_list:
                    if 'sno' in zappi_dict:
                        serial_number = zappi_dict['sno']
                        # Check the zappi serial number matches
                        if str(serial_number) == str(self._zappi_serial_number):
                            # Assign the zappi dict
                            self._zappi_stats_dict = zappi_dict

    def _get_eddi_stat(self, name, throw_error=True):
        """@brief Get a eddi stat after update_stats() has been called.
           @param name The name of the stat of interest.
           @param throw_error True if this method should throw an error if the stats is not found.
           @return The stat or None if not found."""
        stat = None
        # If the stats have not been read yet, read them
        if not self._eddi_stats_dict or name not in self._eddi_stats_dict:
            self.update_stats()

        if self._eddi_stats_dict:
            if name in self._eddi_stats_dict:
                stat = self._eddi_stats_dict[name]

        if throw_error and stat is None:
            raise Exception(f"Failed to read myenergi eddi '{name}={stat}'.")

        return stat

    def _get_zappi_stat(self, name, throw_error=True):
        """@brief Get a zappi stat after update_stats() has been called.
           @param name The name of the stat of interest.
           @param throw_error True if this method should throw an error if the stats is not found.
           @return The stat or None if not found."""
        stat = None
        # If the stats have not been read yet, read them
        if not self._zappi_stats_dict or name not in self._zappi_stats_dict:
            self.update_stats()

        if self._zappi_stats_dict:
            if name in self._zappi_stats_dict:
                stat = self._zappi_stats_dict[name]

        if throw_error and stat is None:
            raise Exception(f"Failed to read myenergi zappi '{name}={stat}'.")

        return stat

    def get_eddi_top_tank_temp(self):
        """@return The eddi top tank temperature or None if not known."""
        return self._get_eddi_stat('tp1')

    def get_eddi_bottom_tank_temp(self):
        """@return The eddi bottom tank temperature or None if not known."""
        return self._get_eddi_stat('tp2')

    def get_eddi_heater_watts(self):
        """@return The eddi heater power in kw or None if not known."""
        return self._get_eddi_stat('ectp1')

    def get_eddi_heater_number(self):
        """@return The eddi heater number that is on.
                   If no heater is on then this stays at the last value.
                   1 = top tank, 2 = bottom tank"""
        return self._get_eddi_stat('hno')

    def get_zappi_charge_mode(self):
        """@return The zappi charge mode or None if not known."""
        return self._get_zappi_stat('zmo')

    def get_zappi_charge_watts(self):
        """@return Get the current charge rate of the zappi in watts."""
        return self._get_zappi_stat('ectp1')

    def get_zappi_plug_status(self):
        """@return Get the ZAPPI EV plug status.
           ZAPPI_PST_EV_DISCONNECTED
           ZAPPI_PST_EV_CONNECTED
           ZAPPI_PST_WAITING_FOR_EV
           ZAPPI_PST_EV_READY_TO_CHARGE
           ZAPPI_PST_EV_CHARGING
           ZAPPI_PST_FAULT
        """
        return self._get_zappi_stat('pst')

    def get_eddi_stats(self):
        """@brief Get the stats of the eddi unit."""
        self._check_eddi_serial_number()
        url = "cgi-jstatus-E"
        return self._exec_api_cmd(url)

    def get_zappi_schedule_list(self):
        """@brief Get the zappi charge schedule list.
           @return A list with four elements. Each element is a list
                   that contains the following three elements
                   0 = The time as HH:MM
                   1 = The duration as HH:MM
                   2 = A comma separated list of days of the week. Each day as three letters."""
        table_row_list = []
        zappi_stats_dict = self.get_zappi_stats()
        if GUIServer.BOOST_TIMES_KEY in zappi_stats_dict:
            for boost_dict in zappi_stats_dict[GUIServer.BOOST_TIMES_KEY]:
                if self._is_valid_boost_dict(boost_dict):
                    """A boost dict contains the following
                        0: bdd The days of the week in the form 01111111.
                            The first 1 indicates that the schedule applies to Mon
                            The next is Tue and so on until Sun.
                            Therefore 01111111 indicate the schedule applies to
                            every day of the week.
                        1: bdh Duration in hours.
                        2: bdm Duration in minutes.
                        3: bsh Time in hours.
                        4: bsm Time in minutes.
                        5: slt The slot. An integer to indicate the schedule slot (11,12,13 or 14)."""
                    bdd = boost_dict[GUIServer.BDD_BOOST_DICT_KEY]
                    bdh = boost_dict[GUIServer.BDH_BOOST_DICT_KEY]
                    bdm = boost_dict[GUIServer.BDM_BOOST_DICT_KEY]
                    bsh = boost_dict[GUIServer.BSH_BOOST_DICT_KEY]
                    bsm = boost_dict[GUIServer.BSM_BOOST_DICT_KEY]
                    table_row = self._get_sched_table_row(bdd,
                                                          bdh,
                                                          bdm,
                                                          bsh,
                                                          bsm)
                    table_row_list.append(table_row)
        return table_row_list

    def _is_valid_boost_dict(self, boost_dict):
        """@brief Determine if the boost dict is valid.
           @return True if all the required keys are present in the boost dict."""
        key_count = 0
        for key in GUIServer.BOOST_DICT_KEYS:
            if key in boost_dict:
                key_count = key_count + 1
        valid = False
        if key_count == 6:
            valid = True
        return valid

    def _get_sched_table_row(self,
                             bdd,
                             bdh,
                             bdm,
                             bsh,
                             bsm):
        """@return A list/row of values from the myenergi zappi charge schedules.
                   0 = start time (HH:MM)
                   1 = duration (HH:MM)
                   2 = Comma separated list of days of the week. Each day in three letter format."""
        day_list = self._get_sched_day_list(bdd)
        duration = f"{bdh:02d}:{bdm:02d}"
        start_time = f"{bsh:02d}:{bsm:02d}"
        table_row = None
        table_row = (start_time, duration, day_list)
        return table_row

    def _get_sched_day_list(self, bdd):
        """@brief Get a list of days that a schedule applies to.
           @param bdd The bdd field from the zappi schedule.
           @return A comma separated list of three letter day names."""
        day_list = []
        if len(bdd) == 8:
            if bdd[1] == '1':
                day_list.append('Mon')
            elif bdd[2] == '1':
                day_list.append('Tue')
            elif bdd[3] == '1':
                day_list.append('Wed')
            elif bdd[4] == '1':
                day_list.append('Thu')
            elif bdd[5] == '1':
                day_list.append('Fri')
            elif bdd[6] == '1':
                day_list.append('Sat')
            elif bdd[7] == '1':
                day_list.append('Sun')
        return ",".join(day_list)

    def get_zappi_stats(self):
        """@brief Get the stats of the zappi unit."""
        self._check_eddi_serial_number()
        self._check_zappi_serial_number()
        url = "cgi-boost-time-Z"+self._zappi_serial_number
        return self._exec_api_cmd(url)

    def set_boost(self, on, mins, relay=None):
        """@brief Set emersion switch on/off
           @param on True sets switch on. If False then switch does not need to be set as both switches are turned off.
           @param mins The number of minutes to boost for.
           @param relay  1 = Top tank heater.
                         2 = bottom tank heater.
                         """
        self._check_eddi_serial_number()
        if on:
            if relay not in (1, 2):
                raise Exception("BUG: set_boost() switch must be 1 or 2.")
            url = "cgi-eddi-boost-E"+self._eddi_serial_number+f"-10-{relay}-{mins}"
        else:
            url = "cgi-eddi-boost-E"+self._eddi_serial_number+"-1-1-0"
            self._exec_api_cmd(url)

            url = "cgi-eddi-boost-E"+self._eddi_serial_number+"-1-2-0"

        self._exec_api_cmd(url)

    def set_tank_schedule(self, on, on_datetime, duration_timedelta, tank):
        """@brief Set a schedule on the hot water tank.
           @param on If True add a schedule. If False delete a schedule.
           @param on_datetime A datetime instance that defines the on time for the tank heater.
           @param duration_timedelta A timedelta instance that defines ho long the tank heater should stay on.
           @param tank The hot water tank (1=top, 2 = bottom)."""
        sched_sub_str = self._get_eddi_schedule_string(on, on_datetime, duration_timedelta, tank)
        url = f"cgi-boost-time-E{self._eddi_serial_number}-{sched_sub_str}"
        self._exec_api_cmd(url)

    def set_water_tank_boost_schedules_off(self):
        """@brief Set the boost tank water schedule off. We reserve the fourth schedule timer for this boost setting, leaving the other timers untouched.
                  Note, we use MyEnergi.TANK_1_BOOST_SCHEDULE_SLOT_ID and MyEnergi.TANK_2_BOOST_SCHEDULE_SLOT_ID schedules for boost purposes
                  rather than using the boost interface commands for the reason details in the _set_boost() method."""
        self.set_tank_schedule(False, None, None, MyEnergi.TOP_TANK_ID)
        self.set_tank_schedule(False, None, None, MyEnergi.BOTTOM_TANK_ID)

    def _get_eddi_schedule_string(self, on, on_datetime, duration_timedelta, tank):
        """@brief Get a timed schedule for a hot water tank.

            cgi-boost-time-E<eddi serial number>-<slot id>-<start time>-<duration>-<day spec>

                start time and duration are both numbers like 60*hours+minutes
                day spec is as bdd above'

            This method returns part of the above string as detailed below.

            '<slot id>-<start time>-<duration>-<day spec>'

           @param on_datetime A datetime instance that defines the on time for the tank heater.
           @param duration_timedelta A timedelta instance that defines ho long the tank heater should stay on.
           @param tank The hot water tank (1=top, 2 = bottom)."""

        self._check_eddi_serial_number()
        if tank not in [MyEnergi.TOP_TANK_ID, MyEnergi.BOTTOM_TANK_ID]:
            raise Exception(f"{tank} is an invalid water tank. Must be {MyEnergi.TOP_TANK_ID} (top) or {MyEnergi.BOTTOM_TANK_ID} (bottom).")

        if tank == 1:
            slot_id = MyEnergi.TANK_1_BOOST_SCHEDULE_SLOT_ID
        else:
            slot_id = MyEnergi.TANK_2_BOOST_SCHEDULE_SLOT_ID

        if on:
            on_time_string = f"{on_datetime.hour:02d}{on_datetime.minute:02d}"
            duration_hours, remainder = divmod(duration_timedelta.seconds, 3600)
            duration_minutes, _ = divmod(remainder, 60)
            duration_string = f"{duration_hours:01d}{duration_minutes:02d}"

            day_of_week = on_datetime.weekday()
            day_of_week_string = self._get_day_of_week_string(day_of_week)

            schedule_string = f"{slot_id:02d}-{on_time_string}-{duration_string}-{day_of_week_string}"

        else:
            schedule_string = f"{slot_id:02d}-0000-000-00000000"

        return schedule_string

    def set_all_zappi_schedules_off(self):
        """@brief Set all zappi charge schedules off.
                  We set charge schedules that have no on time and are not enabled for any days of the week.
                  This causes the 4 possible schedules on the zappi to be removed."""
        self._check_eddi_serial_number()
        self._check_zappi_serial_number()

        for slot_id in MyEnergi.VALID_ZAPPI_SLOT_ID_LIST:
            url = f"cgi-boost-time-Z{self._zappi_serial_number}-{slot_id}-0000-000-00000000"
            self._exec_api_cmd(url)
            # The myenergi system does not always delete the schedule unless a delay occurs between each command
            sleep(1)

    def _get_zappi_charge_string(self, charge_slot_dict, slot_id):
        """@detail Get a string that is formated as required by the myenergi zappi api.

            cgi-boost-time-Z<zappi serial number>-<slot id>-<start time>-<duration>-<day spec>

                start time and duration are both numbers like 60*hours+minutes
                day spec is as bdd above'

            This method returns part of the above string as detailed below.

            '<slot id>-<start time>-<duration>-<day spec>'

           @param charge_slot_dict The dict holding the start stop details of the charge as generated by
                                   GUIServer._set_zappi_charge_thread()
           @param slot_id The slot ID (one of MyEnergi.VALID_ZAPPI_SLOT_ID_LIST).
        """
        if slot_id not in MyEnergi.VALID_ZAPPI_SLOT_ID_LIST:
            valid_list = ",".join(MyEnergi.VALID_ZAPPI_SLOT_ID_LIST)
            raise Exception(f"{slot_id} is an invalid slot id (value = {valid_list})")

        start_datetime = charge_slot_dict[RegionalElectricity.SLOT_START_DATETIME]
        stop_datetime = charge_slot_dict[RegionalElectricity.SLOT_STOP_DATETIME]
        duration_timedelta = stop_datetime-start_datetime
        duration_hours, remainder = divmod(duration_timedelta.seconds, 3600)
        duration_minutes, _ = divmod(remainder, 60)
        day_of_week = start_datetime.weekday()  # where Monday is 0 and Sunday is 6

        # We cannot charge for more than 8 hours 59 mins in one schedule
        if duration_timedelta > timedelta(hours=8, minutes=59):
            raise Exception("A single zappi charge schedule must be less than 9 hours.")

        on_time_string = f"{start_datetime.hour:02d}{start_datetime.minute:02d}"
        duration_string = f"{duration_hours:01d}{duration_minutes:02d}"
        day_of_week_string = self._get_day_of_week_string(day_of_week)

        charge_string = f"{slot_id:02d}-{on_time_string}-{duration_string}-{day_of_week_string}"
        return charge_string

    def _get_day_of_week_string(self, day_of_week):
        """@brief Get the day of the week string used in the command sent to the myenergi server.
           @param day_of_week A single day of the week as an integer 0 - 6.
           @return The day of the week string in the format accepted by the myenergi server."""
        day_of_week_string = None
        if day_of_week == 0:
            day_of_week_string = "01000000"

        elif day_of_week == 1:
            day_of_week_string = "00100000"

        elif day_of_week == 2:
            day_of_week_string = "00010000"

        elif day_of_week == 3:
            day_of_week_string = "00001000"

        elif day_of_week == 4:
            day_of_week_string = "00000100"

        elif day_of_week == 5:
            day_of_week_string = "00000010"

        elif day_of_week == 6:
            day_of_week_string = "00000001"

        if day_of_week_string is None:
            raise Exception("{day_of_week} is an invalid day of the week. Must be 0-6")

        return day_of_week_string

    def _debug(self, msg):
        if self._uio:
            self._uio.debug(f"myenergi API DEBUG: {msg}")

    def _get_base_url(self):
        """@brief Get the URL of the myenergi server that holds this account.
                  The myenergi director server returns the server to use in a response header.
                  This avoids a hard coded server that would stop working if myenergi move the account.
                  Must be called with self._lock held.
           @return The base URL (ends with /)."""
        if self._base_url is None:
            base_url = MyEnergi.FALLBACK_BASE_URL
            try:
                response = requests.get(MyEnergi.DIRECTOR_URL + "cgi-jstatus-E",
                                        auth=HTTPDigestAuth(self._eddi_serial_number, self._api_key),
                                        timeout=MyEnergi.REQUEST_TIMEOUT_SECONDS)
                asn = response.headers.get(MyEnergi.ASN_HEADER)
                if asn and asn != "undefined":
                    base_url = f"https://{asn}/"
                    # Only cache a server name we were actually given so a failed lookup is retried.
                    self._base_url = base_url
                self._debug(f"myenergi director: status={response.status_code}, {MyEnergi.ASN_HEADER}={asn}")
            except requests.RequestException as ex:
                self._debug(f"myenergi director lookup failed ({str(ex)}), using {base_url}")
            return base_url
        return self._base_url

    def _exec_api_cmd(self, path):
        """@brief Run a command using the myenergi api and check for errors.
           @param path The API command (the part of the URL after the server name).
           @return The json response message."""
        # As this maybe called from multiple threads ensure we use acquire a thread lock each time
        # we communicate with the myenergi server.
        with self._lock:
            url = self._get_base_url() + path
            self._debug(f"_exec_api_cmd: url={url}")
            try:
                # A timeout ensures a thread can't hang forever if the network or server stops responding.
                response = requests.get(url,
                                        auth=HTTPDigestAuth(self._eddi_serial_number, self._api_key),
                                        timeout=MyEnergi.REQUEST_TIMEOUT_SECONDS)
            except requests.RequestException:
                # The account may have moved server. Look it up again next time.
                self._base_url = None
                raise
            if response.status_code != 200:
                self._base_url = None
                raise Exception(f"{response.status_code} error code returned from myenergi server.")
            self._debug(f"_exec_api_cmd: response.status_code={response.status_code}")
            response_dict = response.json()

            if response_dict:
                index = 0
                for elem in response_dict:
                    pstr = json.dumps(elem, sort_keys=True, indent=4)
                    self._debug(f"_exec_api_cmd: index={index}, elem={pstr}")
                    index = index+1

                if 'status' in response_dict and response_dict['status'] != 0:
                    raise Exception(f"{response_dict['status']} status code returned from myenergi server (should be 0).")

        return response_dict

    def set_zappi_mode_fast_charge(self):
        """@brief Set the mode of the zappi charger to fast charge."""
        url = f"cgi-zappi-mode-Z{self._zappi_serial_number}-1-0-0-0000"
        self._exec_api_cmd(url)

    def set_zappi_mode_eco(self):
        """@brief Set the mode of the zappi charger to eco"""
        url = f"cgi-zappi-mode-Z{self._zappi_serial_number}-2-0-0-0000"
        self._exec_api_cmd(url)

    def set_zappi_mode_eco_plus(self):
        """@brief Set the mode of the zappi charger to eco+"""
        url = f"cgi-zappi-mode-Z{self._zappi_serial_number}-3-0-0-0000"
        self._exec_api_cmd(url)

    def set_zappi_mode_stop(self):
        """@brief Set the mode of the zappi charger to stop"""
        url = f"cgi-zappi-mode-Z{self._zappi_serial_number}-4-0-0-0000"
        self._exec_api_cmd(url)

    def set_zappi_charge_schedule(self, charge_slot_dict_list):
        """@brief Set the charge schedule for the zappi.
           @param charge_slot_dict_list A list of dicts holding the start stop details of the charge as generated by
                                   GUIServer._set_zappi_charge_thread()."""
        if len(charge_slot_dict_list) > 4:
            raise Exception("Unable to set zappi charge schedule as only 4 schedules can be set.")

        charge_str_list = []
        for charge_slot_dict, slot_id in zip(charge_slot_dict_list, MyEnergi.VALID_ZAPPI_SLOT_ID_LIST):
            charge_str = self._get_zappi_charge_string(charge_slot_dict, slot_id)
            charge_str_list.append(charge_str)

        # I tried removing any existing charge schedules.
        # However if this is executed then the charge schedule fails to get set.
        # Not sure why this occurs.
#        self.set_all_zappi_schedules_off()

        # The zappi charger must be in eco+ mode.
        # We don't need to set eco+ mode as this is checked at a higher level

        # Set each schedule.
        for charge_str in charge_str_list:
            url = f"cgi-boost-time-Z{self._zappi_serial_number}-"+charge_str
            self._exec_api_cmd(url)

    def get_zappi_ev_charge_kwh(self):
        """@return Get the EV charge since the car was plugged in."""
        return self._get_zappi_stat('che')


class ColorButton(ui.button):
    """@brief A button that can change it's background color to one of a number of states."""
    DEFAULT_COLORS = ["blue", 'purple', 'green']

    def __init__(self, callBack=None, *args, **kwargs) -> None:
        # Must exist before super().__init__() as NiceGUI may call update() during construction
        self._color_index = 0
        self._color_list = list(ColorButton.DEFAULT_COLORS)
        super().__init__(*args, **kwargs)
        if callBack:
            self.on('click', callBack)
        self._apply_color()

    def set_button_colors(self, color_list):
        if len(color_list) < 1:
            raise Exception("The list of button colors must include at least one color.")
        self._color_list = color_list
        self._color_index = min(self._color_index, len(color_list) - 1)
        self._apply_color()

    def set_color_index(self, color_index):
        max_index = len(self._color_list) - 1
        if color_index > max_index:   # original wrongly checked self._color_index
            raise Exception(f"{color_index} is an invalid button color index. The maximum color index is {max_index}.")
        if color_index != self._color_index:
            self._color_index = color_index
            self._apply_color()

    def _apply_color(self):
        self.props(f'color={self._color_list[self._color_index]}')


class RegionalElectricity(object):
    """@brief Responsible for reading and processing octopus agile tariff data.
    """
    VALID_REGION_CODE_LIST = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P']
    VALID_REGION_CODE_LIST_WITH_REGIONS = ['A Eastern England',
                                           'B East Midlands',
                                           'C London',
                                           'D North Wales, Merseyside and Cheshire',
                                           'E West Midlands',
                                           'F North East England',
                                           'G North West England',
                                           'H Southern England',
                                           'J South East England',
                                           'K South Wales',
                                           'L South West England',
                                           'M Yorkshire',
                                           'N Southern Scotland',
                                           'P Northern Scotland']
    BOKEH_TOOLS = "box_zoom,reset,save,box_select"
    SLOT_START_DATETIME = "SLOT_START_DATETIME"
    SLOT_STOP_DATETIME = "SLOT_STOP_DATETIME"
    SLOT_COST = "SLOT_COST"

    @staticmethod
    def GET_NEXT_30_MIN_TIME():
        """@brief Get the next time on a 30 minute boundary. On the hour or half hour.
           @return A datetime instance on the next hour or half hour boundary."""
        now = datetime.now().astimezone()
        # Add 30 mins in the future
        next_dt = now + timedelta(minutes=30)
        if next_dt.minute > 30:
            next_dt = next_dt.replace(minute=30, second=0, microsecond=0)
        else:
            next_dt = next_dt.replace(minute=00, second=0, microsecond=0)

        return next_dt

    @staticmethod
    def NEXT_15_MIN_BOUNDARY(dt: datetime) -> datetime:
        """@brief Round datetime up to the next 15-minute boundary.
           @param datetime to be rounded up."""
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)

        # Minutes to add to reach next 15 min slot
        minutes = (15 - dt.minute % 15) % 15

        # If already exactly on a boundary but with seconds, still round up
        if minutes == 0 and (dt.second > 0 or dt.microsecond > 0):
            minutes = 15

        return (dt + timedelta(minutes=minutes)).replace(second=0, microsecond=0)

    def __init__(self, uio):
        """@brief Constructor
           @param uio A UIO instance."""
        self._uio = uio

    def _get_cost_dict(self, region_code):
        """@brief Get a dict of the cost of electricity based on region. See https://mysmartenergy.uk/Electricity-Region for region code list."""
        if region_code not in RegionalElectricity.VALID_REGION_CODE_LIST:
            raise Exception(f'{region_code} is an invalid region code ({",".join(RegionalElectricity.VALID_REGION_CODE_LIST)} are valid).')

        # Note the link https://api.octopus.energy/v1/products/?search=AGILE lists the currently valid AGILE tariffs.
        # This is useful if the link below stops working.

        # Get the energy prices for the next 24 hours or as much as we can obtain at this point in the day.
        now = datetime.now().astimezone()
        startt = RegionalElectricity.NEXT_15_MIN_BOUNDARY(dt=now)
        endt = startt + timedelta(hours=24)
        startts = startt.strftime("%Y-%m-%dT%H:%MZ")
        endts = endt.strftime("%Y-%m-%dT%H:%MZ")
        url_str = f'https://api.octopus.energy/v1/products/AGILE-24-10-01/electricity-tariffs/E-1R-AGILE-24-10-01-{region_code}/standard-unit-rates/?period_from={startts}&period_to={endts}'
        # E.G
        # https://api.octopus.energy/v1/products/AGILE-24-10-01/electricity-tariffs/E-1R-AGILE-24-10-01-A/standard-unit-rates/?period_from=2025-12-23T00:00Z&period_to=2025-12-23T23:30Z

        self._uio.debug(f"Energy cost request URL: {url_str}")
        with urllib.request.urlopen(url_str) as url:
            data = json.load(url)

        resultsDict = data['results']
        costDict = {}
        for record in resultsDict:
            costPence = record["value_inc_vat"]
            startT = datetime.strptime(record["valid_from"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
            costDict[startT] = costPence
        return costDict

    def get_prices(self, region_code, end_charge_time):
        """@brief Get the price of electricity over the next day or so as a dict.
           @param region_code The region of the UK for the electricity prices.
           @param end_charge_time The time (a tuple hours,mins) at which the charging must have completed.
           @return Two lists
                   0 = A list of timestamps. This includes the start and end of each 1/2 hour slot.
                   1 = The price of electricity in £ in that 1/2 hour slot.
                   2 = The end of charge date time object or None if not defined."""

        costDict = self._get_cost_dict(region_code)
        next_30_min_datetime = RegionalElectricity.GET_NEXT_30_MIN_TIME()
        _timeStampList = list(costDict.keys())
        _timeStampList.sort()
        # If the user requires the charge to be complete by a certain time
        end_charge_datetime = None
        if end_charge_time:
            end_charge_datetime = GUIServer.GET_END_CHARGE_DATETIME(end_charge_time)

        timeStampList = []
        costList = []
        for ts in _timeStampList:
            # Ignore all times that are in the past
            if ts < next_30_min_datetime:
                continue
            # Ignore slots that would finish after the end charge time
            if end_charge_datetime and ts + timedelta(minutes=30) > end_charge_datetime:
                continue
            timeStampList.append(ts)
            cost = costDict[ts]/100.0
            # Add the end of this 1/2 hour slot
            costList.append(cost)

        # If we don't have an end of charge time defined
        if not end_charge_datetime:
            # Ensure we have a defined end time (2 days in the future on an hour boundary)
            # This should not interfere with the charge calculation if the octopus agile tariff is selected.
            now = datetime.now().astimezone()
            end_charge_datetime = now + timedelta(hours=48)
            end_charge_datetime = end_charge_datetime.replace(minute=0, second=0, microsecond=0)

        return (timeStampList, costList, end_charge_datetime)


class TankTempHistory(object):
    """@brief Responsible for holding a rolling history of the hot water tank temperatures
              and immersion heater state and persisting it to a CSV file so that it survives a restart.

              Each sample is a tuple
              0 = timestamp (timezone aware datetime)
              1 = top tank temperature (°C)
              2 = bottom tank temperature (°C)
              3 = heater power (W) or None if not known
              4 = heater number (1 = top, 2 = bottom) or None if not known"""
    CSV_HEADER = ("timestamp", "top_c", "bottom_c", "heater_w", "heater_no")

    def __init__(self, filename, max_age_hours, uio=None):
        """@brief Constructor
           @param filename The CSV file that the samples are stored in.
           @param max_age_hours Samples older than this are discarded.
           @param uio A UIO instance."""
        self._filename = filename
        self._max_age = timedelta(hours=max_age_hours)
        self._uio = uio
        self._lock = threading.Lock()
        self._samples = []
        self._last_file_rewrite = None
        self._load()

    def _debug(self, msg):
        if self._uio:
            self._uio.debug(f"TankTempHistory: {msg}")

    @staticmethod
    def _optional_number(text, convert):
        """@return The text converted to a number or None if empty/invalid."""
        try:
            return convert(text) if text not in (None, "") else None
        except ValueError:
            return None

    def _load(self):
        """@brief Load the history from the CSV file (if present) and drop old samples.
                  Files written before heater power was recorded (3 columns) are still read."""
        samples = []
        if os.path.isfile(self._filename):
            try:
                with open(self._filename, 'r', newline='') as fd:
                    for row in csv.reader(fd):
                        if len(row) not in (3, 5) or row[0] == TankTempHistory.CSV_HEADER[0]:
                            continue
                        try:
                            ts = datetime.fromisoformat(row[0])
                            top = float(row[1])
                            bottom = float(row[2])
                        except ValueError:
                            # Ignore corrupt lines (E.G a partly written line after a power cut)
                            continue
                        heater_w = heater_no = None
                        if len(row) == 5:
                            heater_w = TankTempHistory._optional_number(row[3], float)
                            heater_no = TankTempHistory._optional_number(row[4], int)
                        samples.append((ts, top, bottom, heater_w, heater_no))
            except Exception as ex:
                if self._uio:
                    self._uio.error(f"Failed to read {self._filename}: {str(ex)}")
        with self._lock:
            self._samples = samples
            self._prune()
        # Rewrite the file so that it only holds the samples we've kept (in the current format).
        self._rewrite_file()
        self._debug(f"Loaded {len(self._samples)} tank samples from {self._filename}")

    def _prune(self):
        """@brief Remove samples older than the max age. The lock must be held by the caller."""
        oldest_allowed = datetime.now().astimezone() - self._max_age
        self._samples = [s for s in self._samples if s[0] >= oldest_allowed]

    @staticmethod
    def _to_row(sample):
        """@return A CSV row for a sample."""
        ts, top, bottom, heater_w, heater_no = sample
        return (ts.isoformat(timespec='seconds'),
                f"{top:.1f}",
                f"{bottom:.1f}",
                "" if heater_w is None else f"{heater_w:.0f}",
                "" if heater_no is None else str(heater_no))

    def _rewrite_file(self):
        """@brief Write all the held samples to the CSV file."""
        with self._lock:
            samples = list(self._samples)
        tmp_file = self._filename + ".tmp"
        with open(tmp_file, 'w', newline='') as fd:
            writer = csv.writer(fd)
            writer.writerow(TankTempHistory.CSV_HEADER)
            for sample in samples:
                writer.writerow(TankTempHistory._to_row(sample))
        # Atomic replace so a crash can't leave us with a half written file.
        os.replace(tmp_file, self._filename)
        self._last_file_rewrite = datetime.now()

    def add(self, top_c, bottom_c, heater_w=None, heater_no=None):
        """@brief Add a sample (timestamped now).
           @param top_c The top tank temperature in °C.
           @param bottom_c The bottom tank temperature in °C.
           @param heater_w The immersion heater power in watts or None if not known.
           @param heater_no The heater that was last on (1 = top, 2 = bottom) or None if not known."""
        ts = datetime.now().astimezone().replace(microsecond=0)
        sample = (ts,
                  float(top_c),
                  float(bottom_c),
                  None if heater_w is None else float(heater_w),
                  None if heater_no is None else int(heater_no))
        with self._lock:
            self._samples.append(sample)
            self._prune()

        # Append to the file. Once an hour rewrite it to drop old samples so it does not grow forever.
        if self._last_file_rewrite is None or datetime.now() - self._last_file_rewrite > timedelta(hours=1):
            self._rewrite_file()
        else:
            with open(self._filename, 'a', newline='') as fd:
                csv.writer(fd).writerow(TankTempHistory._to_row(sample))

    def get(self, hours):
        """@brief Get the samples recorded over the last N hours.
           @param hours The number of hours of history required.
           @return A list of sample tuples (see class description), oldest first."""
        oldest = datetime.now().astimezone() - timedelta(hours=hours)
        with self._lock:
            return [s for s in self._samples if s[0] >= oldest]

    def clear(self):
        """@brief Delete all recorded samples."""
        with self._lock:
            self._samples = []
        self._rewrite_file()


class ClientView(object):
    """@brief Holds the GUI elements for one browser connection.
              Each browser (E.G a phone and a PC) gets its own set so they don't interfere with each other.
              Messages from the worker threads are sent to every connected browser."""

    def __init__(self):
        self._add_free_elect_period_dialog = None
        self._add_tariff_dialog = None
        self._add_tariff_value_button = None
        self._api_key = None
        self._boost_bottom_button = None
        self._boost_stop_button = None
        self._boost_time_value = None
        self._boost_top_button = None
        self._boost_until_datetime = None
        self._bootMinsSlider = None
        self._bottomTankTempLabel = None
        self._calc_button = None
        self._clear_tariff_value_button = None
        self._clear_zappi_button = None
        self._config_save_button = None
        self._current_ev_charge_input = None
        self._eddi_serial_number = None
        self._electricity_region_code = None
        self._end_charge_time_input = None
        self._ev_kwh = None
        self._free_energy_checkbox = None
        self._get_button = None
        self._heater_shade_checkbox = None
        self._other_tariff_plot_container = None
        self._plot_container = None
        self._set_button = None
        self._target_ev_charge_input = None
        self._tariff_radio = None
        self._temp_period_select = None
        self._temp_plot_container = None
        self._topTankTempLabel = None
        self._undershoot_checkbox = None
        self._zappi_max_charge_rate = None
        self._zappi_serial_number = None
        self._buttonList = []
        self.queue = Queue()


class GUIServer(object):

    MYENERGI_API_KEY = 'MYENERGI_API_KEY'
    EDDI_SERIAL_NUMBER = 'EDDI_SERIAL_NUMBER'
    ZAPPI_SERIAL_NUMBER = 'ZAPPI_SERIAL_NUMBER'
    ZAPPI_MAX_CHARGE_RATE = 'ZAPPI_MAX_CHARGE_RATE'
    ELECTRICITY_REGION_CODE = 'ELECTRICITY_REGION_CODE'
    OCTOPUS_AGILE_TARIFF = 'OCTOPUS_AGILE_TARIFF'
    TARIFF_POINT_LIST = "TARIFF_POINT_LIST"
    EV_BATTERY_KWH = "EV_BATTERY_KWH"
    CURRENT_EV_CHARGE_PERCENTAGE = "CURRENT_EV_CHARGE_PERCENTAGE"
    TARGET_EV_CHARGE_PERCENTAGE = "TARGET_EV_CHARGE_PERCENTAGE"
    READY_BY = "READY_BY"
    CLEAR_ZAPPI_SCHEDULE_TIME = "CLEAR_ZAPPI_SCHEDULE_TIME"
    CLEAR_EDDI_SCHEDULE_TIME = "CLEAR_EDDI_SCHEDULE_TIME"
    UNDERSHOOT_CHARGE = "UNDERSHOOT_CHARGE"

    DEFAULT_CONFIG = {MYENERGI_API_KEY: "",
                      EDDI_SERIAL_NUMBER: "",
                      ZAPPI_SERIAL_NUMBER: "",
                      ZAPPI_MAX_CHARGE_RATE: "7.4",
                      ELECTRICITY_REGION_CODE: "",
                      OCTOPUS_AGILE_TARIFF: True,
                      TARIFF_POINT_LIST: [],
                      EV_BATTERY_KWH: "0",
                      CURRENT_EV_CHARGE_PERCENTAGE: 20,
                      TARGET_EV_CHARGE_PERCENTAGE: 80,
                      READY_BY: "",
                      CLEAR_ZAPPI_SCHEDULE_TIME: "",
                      CLEAR_EDDI_SCHEDULE_TIME: "",
                      UNDERSHOOT_CHARGE: False}

    TAB_BAR_STYLE = 'font-size: 20px; color: lightgreen;'
    TEXT_STYLE_A = 'font-size: 40px; color: white;'
    TEXT_STYLE_A_SIZE = 'font-size: 20px;'
    TEXT_STYLE_B = 'font-size: 40px; color: lightgreen;'
    TEXT_STYLE_C = 'font-size: 15px; color: lightgreen;'
    TEXT_STYLE_D_SIZE = 'font-size: 40px;'
    TEXT_STYLE_E_SIZE = 'font-size: 30px;'

    BOOST_1_ON = "BOOST_1_SET_ON"
    BOOST_2_ON = "BOOST_2_SET_ON"
    BOOST_OFF = "BOOST_OFF"
    TANK_TEMPERATURES = "TANK_TEMPERATURES"
    INFO_MESSAGE = "INFO_MESSAGE"
    ERROR_MESSAGE = "ERROR_MESSAGE"
    WARNING_MESSAGE = "WARNING_MESSAGE"
    CLEAR_PLOT = "CLEAR_PLOT"
    MIN_STATS_UPDATE_SECONDS = 10.0                 # The minimum time between myenergi server stats reads.
    MAX_STATS_UPDATE_SECONDS = 60.0                 # The maximum time between myenergi server stats reads.
    STATS_READ_INC_FACTOR = 1.2                     # A factor used to move from MIN_STATS_UPDATE_SECONDS to MAX_STATS_UPDATE_SECONDS
    DEFAULT_SERVER_PORT = 8080
    GUI_POLL_SECONDS = 0.1
    TARIFF_LIST = ["Octopus Agile Tariff", 'Other Tariff']
    SET_ZAPPI_CHARGE_SCHEDULE_MESSAGE = "Set zappi charge schedule"
    DEFAULT_BUTTON_COLOR = "blue"
    CLEARED_ALL_CHARGING_SCHEDULES = "Cleared all zappi charging schedules."
    ZAPPI_CHARGE_SCHEDULE = "ZAPPI_CHARGE_SCHEDULE"
    ZAPPI_CHARGE_COMPLETE_MESSAGE = "ZAPPI_CHARGE_COMPLETE_MESSAGE"

    BOOST_TIMES_KEY = "boost_times"
    BDD_BOOST_DICT_KEY = 'bdd'
    BDH_BOOST_DICT_KEY = 'bdh'
    BDM_BOOST_DICT_KEY = 'bdm'
    BSH_BOOST_DICT_KEY = 'bsh'
    BSM_BOOST_DICT_KEY = 'bsm'
    SLT_BOOST_DICT_KEY = 'slt'

    BOOST_DICT_KEYS = [BDD_BOOST_DICT_KEY,
                       BDH_BOOST_DICT_KEY,
                       BDM_BOOST_DICT_KEY,
                       BSH_BOOST_DICT_KEY,
                       BSM_BOOST_DICT_KEY,
                       SLT_BOOST_DICT_KEY
                       ]
    PLOT_OPTIMAL_CHARGE_TIMES = "PLOT_OPTIMAL_CHARGE_TIMES"

    BUTTON_LOW_INDEX = 0
    BUTTON_MID_INDEX = 1
    BUTTON_HIGH_INDEX = 2

    ADD_TARIFF_START_TIME = "Start time"
    ADD_TARIFF_PRICE = "Price (£)"

    ZERO_COST_ELEC_START_TIME = "Start time"
    ZERO_COST_ELEC_DURATION = "Duration"

    MAX_HEATER_WATTS = 2500
    MIN_HEATER_WATTS = 100
    HEATER_SOURCE_NONE = 0
    HEATER_SOURCE_SOLAR = 1
    HEATER_SOURCE_MAINS = 2
    # Shading used on the tank temperature plot. Colours match the EDDI tab boost buttons.
    HEATER_SHADE_COLORS = {HEATER_SOURCE_SOLAR: 'yellow',
                           HEATER_SOURCE_MAINS: 'green'}
    HEATER_SHADE_OPACITY = 0.3

    ZAPPI_CHARGE_ADJUSTMENT_FACTOR_FLOAT = "ZAPPI_CHARGE_ADJUSTMENT_FACTOR_FLOAT"
    CMD_LINE_CONFIG_FILENAME = "myenergi_display_command_line.cfg"
    TANK_TEMP_RECORD_SECONDS_INT = "TANK_TEMP_RECORD_SECONDS_INT"
    TANK_TEMP_HISTORY_DAYS_INT = "TANK_TEMP_HISTORY_DAYS_INT"
    DEFAULT_TANK_TEMP_RECORD_SECONDS = 60
    DEFAULT_TANK_TEMP_HISTORY_DAYS = 7
    DEFAULT_CMD_LINE_CONFIG = {
        ZAPPI_CHARGE_ADJUSTMENT_FACTOR_FLOAT: "1.0",
        TANK_TEMP_RECORD_SECONDS_INT: DEFAULT_TANK_TEMP_RECORD_SECONDS,
        TANK_TEMP_HISTORY_DAYS_INT: DEFAULT_TANK_TEMP_HISTORY_DAYS,
    }
    CMD_LINE_CONFIG_ATTR_DICT = {
        ZAPPI_CHARGE_ADJUSTMENT_FACTOR_FLOAT: ConfigAttrDetails("Enter the ZAPPI charge adjustment factor (default = 1.0)", 0.0, 3.0),
        TANK_TEMP_RECORD_SECONDS_INT: ConfigAttrDetails(f"Enter the seconds between tank temperature recordings (default = {DEFAULT_TANK_TEMP_RECORD_SECONDS})", 30, 3600),
        TANK_TEMP_HISTORY_DAYS_INT: ConfigAttrDetails(f"Enter the number of days of tank temperature history to keep (default = {DEFAULT_TANK_TEMP_HISTORY_DAYS})", 1, 366),
    }

    TANK_TEMP_HISTORY_FILENAME = "myenergi_display_tank_temps.csv"
    # Selectable plot periods (label -> hours)
    TEMP_PLOT_PERIODS = {"6 hours": 6,
                         "24 hours": 24,
                         "3 days": 72,
                         "7 days": 168}
    DEFAULT_TEMP_PLOT_PERIOD = "24 hours"
    TEMP_PLOT_AUTO_REFRESH_SECONDS = 60
    HOUSEKEEPING_SECONDS = 10

    @staticmethod
    def Print_Exception():
        """@brief Print an exception traceback."""
        lines = traceback.format_exc().split("\n")
        for line in lines:
            print(line)

    def __init__(self, uio, port):
        """@brief Constructor
           @param uio A UIO instance.
           @param port The TCP port to bind the nicegui server."""
        self._uio = uio
        self._port = port
        self._init_stats_read_delay = True            # A flag to initialize the stats read time
        self._my_energi = MyEnergi('')
        self._heater_load_watts = 0
        self._zappi_charge_watts = 0
        self._relay_on = 0
        self._eddi_heater_button_selected = 0
        self._charge_slot_dict_list = None
        self._octopus_agile_tariff = True
        self._other_tariff_values = []
        self._read_temp_thread = None
        self._zappi_charge_schedule_active = False
        self._start_charge_zappi_kwh = 0.0
        self._target_ev_charge_kwh = 0.0
        self._cfg_mgr = DotConfigManager(GUIServer.DEFAULT_CONFIG, uio=self._uio)
        self._load_config()
        self._cmd_line_config_manager = ConfigManager(self._uio, GUIServer.CMD_LINE_CONFIG_FILENAME, GUIServer.DEFAULT_CMD_LINE_CONFIG)
        self._cmd_line_config_manager.load(self)

        # Tank temperature recording
        self._background_stop_event = threading.Event()
        self._background_threads = []
        self._cfg_lock = threading.Lock()
        # Each browser connection has its own widgets (ClientView instance), keyed by NiceGUI client id.
        self._client_views = {}
        history_days = self._get_cmd_line_int(GUIServer.TANK_TEMP_HISTORY_DAYS_INT, GUIServer.DEFAULT_TANK_TEMP_HISTORY_DAYS)
        history_file = os.path.join(DotConfigManager.GetDefaultConfigFolder(), GUIServer.TANK_TEMP_HISTORY_FILENAME)
        self._tank_temp_history = TankTempHistory(history_file, history_days*24, uio=self._uio)

    def _reset_polling_rate(self):
        """@brief This is called to reset the polling rate (set to min delay between reads)."""
        self._init_stats_read_delay = True

    def _read_stats_now(self):
        """@brief Determine if it's time to read the stats from the myenergi server.
           @return True if it's time, False if not."""
        read_stats_now = False
        if self._init_stats_read_delay:
            self._init_stats_read_delay = False
            self._next_stats_read_time = time() + GUIServer.MIN_STATS_UPDATE_SECONDS
            self._current_stats_read_delay = GUIServer.MIN_STATS_UPDATE_SECONDS
            read_stats_now = True
            self._debug(f"self._read_stats_now(): Read stats {GUIServer.MIN_STATS_UPDATE_SECONDS} seconds from now.")

        else:
            # When running the stats are read from the myenergi server. The delay between
            # each read starts at GUIServer.MIN_STATS_UPDATE_SECONDS and moves to
            # GUIServer.MAX_STATS_UPDATE_SECONDS as time passes.

            # If we are in a state where the read delay has reached the max, calc the next read time.
            if self._current_stats_read_delay >= GUIServer.MAX_STATS_UPDATE_SECONDS:
                self._current_stats_read_delay = GUIServer.MAX_STATS_UPDATE_SECONDS
                # If its time to read stats
                if time() >= self._next_stats_read_time:
                    read_stats_now = True
                    # Calc the next read time.
                    self._next_stats_read_time = time() + self._current_stats_read_delay
                    self._debug(f"self._read_stats_now(): Max stats read delay of {self._current_stats_read_delay} seconds reached.")

            else:
                # If its time to read stats
                if time() >= self._next_stats_read_time:
                    # Inc the delay between reads and calc the next read time.
                    new_stats_read_delay = self._current_stats_read_delay * GUIServer.STATS_READ_INC_FACTOR
                    self._next_stats_read_time = time() + new_stats_read_delay
                    read_stats_now = True
                    self._current_stats_read_delay = new_stats_read_delay
                    if self._current_stats_read_delay > GUIServer.MAX_STATS_UPDATE_SECONDS:
                        self._current_stats_read_delay = GUIServer.MAX_STATS_UPDATE_SECONDS
                    self._debug(f"self._read_stats_now(): Read stats in {self._current_stats_read_delay} seconds time.")

        return read_stats_now

    def _load_config(self):
        """@brief Load the config from a config file."""
        try:
            self._cfg_mgr.load()
            self._create_myenergi()
            self._other_tariff_values = self._cfg_mgr.getAttr(GUIServer.TARIFF_POINT_LIST)

        except Exception:
            # If config does not exist we use the defaults
            pass

    def _create_myenergi(self):
        """@brief Create an object to talk to the myenergi products."""
        self._my_energi = MyEnergi(self._cfg_mgr.getAttr(GUIServer.MYENERGI_API_KEY), uio=self._uio)
        self._my_energi.set_eddi_serial_number(self._cfg_mgr.getAttr(GUIServer.EDDI_SERIAL_NUMBER))
        self._my_energi.set_zappi_serial_number(self._cfg_mgr.getAttr(GUIServer.ZAPPI_SERIAL_NUMBER))

    def _save_charge_fields(self):
        """@brief Save the ZAPPI tab charge fields so they are restored next time. No network access."""
        self._cfg_mgr.addAttr(GUIServer.CURRENT_EV_CHARGE_PERCENTAGE, self._w._current_ev_charge_input.value)
        self._cfg_mgr.addAttr(GUIServer.TARGET_EV_CHARGE_PERCENTAGE, self._w._target_ev_charge_input.value)
        self._cfg_mgr.addAttr(GUIServer.READY_BY, self._w._end_charge_time_input.value)
        self._cfg_mgr.addAttr(GUIServer.UNDERSHOOT_CHARGE, self._w._undershoot_checkbox.value)
        self._store_config()

    async def _save_settings(self):
        """@brief Validate and save the settings tab. Access to the myenergi units is checked in
                  a separate thread so the GUI does not freeze while waiting for the server.
           @return True if saved."""
        api_key = self._w._api_key.value or ""
        eddi_serial_number = self._w._eddi_serial_number.value or ""
        zappi_serial_number = self._w._zappi_serial_number.value or ""
        zappi_max_charge_rate = self._w._zappi_max_charge_rate.value or ""
        ev_kwh = self._w._ev_kwh.value
        region_code = self._w._electricity_region_code.value
        octopus_agile_tariff = self._is_octopus_agile_tariff_enabled()

        # Check the fields that don't need network access first.
        if len(api_key) > 0 and len(zappi_serial_number) > 0:
            if float(ev_kwh or 0) <= 0:
                ui.notify("EV battery capacity must be greater than 0 kWh.", type='negative')
                return False

            if region_code is None or region_code not in RegionalElectricity.VALID_REGION_CODE_LIST_WITH_REGIONS:
                ui.notify("Electricity region code must be set.", type='negative')
                return False

            # The user may leave the zappi charge rate field empty
            if len(zappi_max_charge_rate) > 0:
                try:
                    float(zappi_max_charge_rate)
                except ValueError:
                    ui.notify(f"{zappi_max_charge_rate} is an invalid zappi charge rate (kW).", type='negative')
                    return False

        if len(api_key) > 0 and len(eddi_serial_number) > 0:
            error = await run.io_bound(GUIServer.CHECK_EDDI_ACCESS, api_key, eddi_serial_number)
            if error:
                ui.notify(f"eddi: {error}", type='negative')
                return False
            ui.notify("Successfully read eddi stats.", position='center')
            self._cfg_mgr.addAttr(GUIServer.MYENERGI_API_KEY, api_key)
            self._cfg_mgr.addAttr(GUIServer.EDDI_SERIAL_NUMBER, eddi_serial_number)

        if len(api_key) > 0 and len(zappi_serial_number) > 0:
            error = await run.io_bound(GUIServer.CHECK_ZAPPI_ACCESS, api_key, eddi_serial_number, zappi_serial_number)
            if error:
                ui.notify(f"zappi: {error}", type='negative')
                ui.notify("zappi access failed. Check API Key and zappi serial number.", type='negative')
                return False
            ui.notify("Successfully read zappi stats.", position='center')
            self._cfg_mgr.addAttr(GUIServer.MYENERGI_API_KEY, api_key)
            self._cfg_mgr.addAttr(GUIServer.ZAPPI_SERIAL_NUMBER, zappi_serial_number)
            self._cfg_mgr.addAttr(GUIServer.EV_BATTERY_KWH, float(ev_kwh))
            self._cfg_mgr.addAttr(GUIServer.ELECTRICITY_REGION_CODE, region_code)
            self._cfg_mgr.addAttr(GUIServer.ZAPPI_MAX_CHARGE_RATE, zappi_max_charge_rate)
            self._cfg_mgr.addAttr(GUIServer.OCTOPUS_AGILE_TARIFF, octopus_agile_tariff)
            self._cfg_mgr.addAttr(GUIServer.TARIFF_POINT_LIST, self._other_tariff_values)

        self._save_charge_fields()
        ui.notify(f"Saved to {self._cfg_mgr._getConfigFile()}")
        return True

    def _is_octopus_agile_tariff_enabled(self):
        """@brief Determine if the user has selectedt the Octopus agile tariff.
           @return True if enabled false if not."""
        octopus_agile_tariff = False
        if self._w._tariff_radio.value == GUIServer.TARIFF_LIST[0]:
            octopus_agile_tariff = True
        return octopus_agile_tariff

    def _info(self, msg):
        """@brief Show an info level message."""
        if self._uio:
            self._uio.info(msg)

    def _error(self, msg):
        """@brief Show an error level message."""
        if self._uio:
            self._uio.error(msg)

    def _debug(self, msg):
        """@brief Show an debug level message."""
        if self._uio:
            self._uio.debug(msg)

    def create_gui(self, nicegui_debug_enabled, reload=False, show=False):
        """@brief Start the GUI server.
           @param nicegui_debug_enabled True enables debug of the nicegui server.
           @param reload If True restart when this file is updated. Useful for dev.
           @param show If True show the GUI on startup, ie open a browser window."""
        pageTitle = f"myenergi display (V{TabbedNiceGui.GetProgramVersion()})"
        guiLogLevel = "debug" if nicegui_debug_enabled else "warning"
        # Start/stop the tank temperature recorder with the server. Using the startup hook (rather than
        # starting a thread here) ensures only one recorder runs when --reload is used.
        app.on_startup(self._start_background_threads)
        app.on_shutdown(self._stop_background_threads)
        ui.run(root=self._build_page,
               host="0.0.0.0",
               port=self._port,
               title=pageTitle,
               dark=True,
               uvicorn_logging_level=guiLogLevel,
               reload=reload,
               show=show)

    @property
    def _w(self):
        """@return The ClientView (widgets) of the browser connection whose event is being handled."""
        return self._client_views[ui.context.client.id]

    def _build_page(self):
        """@brief Build the GUI elements. Called by NiceGUI for each browser connection."""
        client = ui.context.client
        self._client_views[client.id] = ClientView()
        # Forget this browser's widgets when it goes away.
        client.on_delete(lambda: self._client_views.pop(client.id, None))

        tabNameList = ('EDDI', 'TEMPS', 'ZAPPI', 'SETTINGS')
        iconList = ('home', 'thermostat', 'electric_car', 'settings')
        tabMethodInitList = [self._init_eddi_tab,
                             self._init_temps_tab,
                             self._init_zappi_tab,
                             self._init_settings_tab]
        tabObjList = []
        with ui.row().style(GUIServer.TAB_BAR_STYLE):
            with ui.tabs().classes('w-full') as tabs:
                for tabName, iconName in zip(tabNameList, iconList):
                    tabObjList.append(ui.tab(tabName, icon=iconName))

            with ui.tab_panels(tabs, value=tabObjList[0]).classes('w-full'):
                for tabObj, init_method in zip(tabObjList, tabMethodInitList):
                    with ui.tab_panel(tabObj):
                        init_method()

        ui.timer(interval=GUIServer.GUI_POLL_SECONDS, callback=self._gui_timer_callback)

    @staticmethod
    def GET_HEATER_SOURCE(heater_watts):
        """@brief Infer the source of the power to the immersion heater from the power it is taking.
           @param heater_watts The heater power in watts.
           @return GUIServer.HEATER_SOURCE_MAINS, GUIServer.HEATER_SOURCE_SOLAR or GUIServer.HEATER_SOURCE_NONE."""
        source = GUIServer.HEATER_SOURCE_NONE
        if heater_watts is not None:
            if heater_watts > GUIServer.MAX_HEATER_WATTS:
                source = GUIServer.HEATER_SOURCE_MAINS
            elif heater_watts > GUIServer.MIN_HEATER_WATTS:
                source = GUIServer.HEATER_SOURCE_SOLAR
        return source

    def _get_heater_power(self, relay):
        """@brief Determine how much power the heater is taking and from this infer the
                  source of the power.
           @param relay 1 == top tank heater. 2 == Bottom tank heater.
           @return 2 >= AC Mains
                   1 >= Solar Power
                   0 = No detected power."""
        detected_power = GUIServer.HEATER_SOURCE_NONE
        # If the relay of interest is on
        if self._relay_on == relay:
            detected_power = GUIServer.GET_HEATER_SOURCE(self._heater_load_watts)
        return detected_power

    def _get_zappi_charging(self):
        """@brief Determine if the zappi is charging an EV.
           @return True if the EV is charging."""
        ev_charging = False
        # We use a threshold of 1400 watts as 1500 watts appears to be the min ev charge rate.
        if self._zappi_charge_watts > 1400:
            ev_charging = True
        return ev_charging

    def _gui_timer_callback(self):
        """@called periodically (quickly) to allow updates of the GUI."""

        while not self._w.queue.empty():
            rxMessage = self._w.queue.get()
            if isinstance(rxMessage, dict):
                self._process_rx_dict(rxMessage)

        # If it's time toe read the stats
        if self._read_stats_now():
            # Don't update the tank temperatures in the gui thread or the gui thread will block
            # if there are issues getting data over the internet.
            # Only start a new thread if we haven't started one yet or the old one has completed.
            # This stops many threads backing up if there are internet connectivity issues.
            if self._read_temp_thread is None or not self._read_temp_thread.is_alive():
                self._read_temp_thread = threading.Thread(target=self._update_stats, daemon=True)
                self._read_temp_thread.start()

        relay_1_color_index = self._get_heater_power(1)
        self._w._boost_top_button.set_color_index(relay_1_color_index)

        relay_2_color_index = self._get_heater_power(2)
        # Ensure both heaters cannot be on at the same time
        # This should never happen.
        if relay_1_color_index != 0:
            relay_2_color_index = 0
        self._w._boost_bottom_button.set_color_index(relay_2_color_index)

        ev_charging = self._get_zappi_charging()
        if ev_charging:
            self._w._set_button.set_color_index(GUIServer.BUTTON_HIGH_INDEX)
        else:
            if self._zappi_charge_schedule_active:
                self._w._set_button.set_color_index(GUIServer.BUTTON_MID_INDEX)
            else:
                self._w._set_button.set_color_index(GUIServer.BUTTON_LOW_INDEX)

    def _get_clear_eddi_boost_schedule_time(self):
        """@brief Get the time to clear the eddi boost schedule. If a schedule has been set
                  then it is cleared when the tank heating has completed.
           @return A datetime instance or None if not defined."""

        clear_datetime = None
        try:
            datetime_str = self._cfg_mgr.getAttr(GUIServer.CLEAR_EDDI_SCHEDULE_TIME)
            clear_datetime = datetime.strptime(datetime_str, "%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            pass
        return clear_datetime

    def _get_clear_zappi_schedule_time(self):
        """@brief Get the time to clear the zappi schedule. If a schedule has been set
                  then it is cleared when the charge has been completed or when the
                  clear schedule button is selected.
           @return A datetime instance or None if not defined."""
        clear_datetime = None
        try:
            datetime_str = self._cfg_mgr.getAttr(GUIServer.CLEAR_ZAPPI_SCHEDULE_TIME)
            clear_datetime = datetime.strptime(datetime_str, "%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            pass
        return clear_datetime

    def _store_config(self):
        """@brief Save the config to file. Safe to call from any thread."""
        with self._cfg_lock:
            self._cfg_mgr.store()

    def _housekeeping_thread(self):
        """@brief Remove the eddi boost and zappi charge schedules once they have finished.
                  This runs in the background so schedules are removed even when no browser is
                  connected. Otherwise they would repeat on the same day next week."""
        while not self._background_stop_event.is_set():
            try:
                now = datetime.now()
                clear_eddi_time = self._get_clear_eddi_boost_schedule_time()
                if clear_eddi_time and clear_eddi_time <= now:
                    self._info("Removing the finished eddi boost schedule.")
                    self._cfg_mgr.addAttr(GUIServer.CLEAR_EDDI_SCHEDULE_TIME, "")
                    self._store_config()
                    self._set_boost(False, None, None)

                clear_zappi_time = self._get_clear_zappi_schedule_time()
                if clear_zappi_time and clear_zappi_time <= now:
                    self._info("Removing the finished zappi charge schedule.")
                    self._cfg_mgr.addAttr(GUIServer.CLEAR_ZAPPI_SCHEDULE_TIME, "")
                    self._store_config()
                    # Reset this so that the Set button returns to it's original color.
                    self._zappi_charge_schedule_active = False
                    # Report the kWh added to the EV
                    self._clear_zappi_charge_schedules_thread(send_charged_msg=True)
            except Exception as ex:
                self._error(f"Housekeeping error: {str(ex)}")
            self._background_stop_event.wait(GUIServer.HOUSEKEEPING_SECONDS)

    def _process_rx_dict(self, rxDict):
        """@brief Process the dicts received from the GUI message queue.
           @param rxDict The dict received from the GUI message queue."""

        if GUIServer.BOOST_1_ON in rxDict:
            ui.notify(f'Set top tank heater boost on for {self._w._bootMinsSlider.value} mins.')

        elif GUIServer.BOOST_2_ON in rxDict:
            ui.notify(f'Set bottom tank heater boost on for {self._w._bootMinsSlider.value} mins.')

        elif GUIServer.BOOST_OFF in rxDict:
            ui.notify('Set top and bottom tank heaters off.')

        elif GUIServer.ERROR_MESSAGE in rxDict:
            error_message = rxDict[GUIServer.ERROR_MESSAGE]
            self._w._clear_zappi_button.enable()
            ui.notify(f"{error_message}", type='negative')
            if error_message.startswith("-5 status code returned from myenergi server"):
                ui.notify("The myenergi system may still processing the previous command. Wait some time before trying again.")

        elif GUIServer.INFO_MESSAGE in rxDict:
            info_message = rxDict[GUIServer.INFO_MESSAGE]
            ui.notify(info_message)
            # If we have confirmation from myenergi that the charge schedule was applied
            if info_message == GUIServer.SET_ZAPPI_CHARGE_SCHEDULE_MESSAGE:
                ui.notify("Wait a few mins before selecting the Get button to check the schedule is set on your ZAPPI.", type='warning', timeout=5000)
                self._set_zappi_charge_active(True)
            # If we have confirmation from myenergi that all charge schedules were removed
            if info_message == GUIServer.CLEARED_ALL_CHARGING_SCHEDULES:
                self._set_zappi_charge_active(False)
                self._w._clear_zappi_button.enable()

        elif GUIServer.TANK_TEMPERATURES in rxDict:
            top_tank_temp, bottom_tank_temp = rxDict[GUIServer.TANK_TEMPERATURES]
            self._w._topTankTempLabel.text = top_tank_temp
            self._w._bottomTankTempLabel.text = bottom_tank_temp

        elif GUIServer.ZAPPI_CHARGE_SCHEDULE in rxDict:
            zappi_charge_table = rxDict[GUIServer.ZAPPI_CHARGE_SCHEDULE]
            self._display_zappi_charge_table(zappi_charge_table)

        elif GUIServer.PLOT_OPTIMAL_CHARGE_TIMES in rxDict:
            argList = rxDict[GUIServer.PLOT_OPTIMAL_CHARGE_TIMES]
            self._plot_optimal_charge_times(argList)

        elif GUIServer.CLEAR_PLOT in rxDict:
            if self._w._plot_container:
                self._w._plot_container.clear()

        elif GUIServer.ZAPPI_CHARGE_COMPLETE_MESSAGE in rxDict:
            charge_complete_msg = rxDict[GUIServer.ZAPPI_CHARGE_COMPLETE_MESSAGE]
            self._persistent_notify(charge_complete_msg)

        elif GUIServer.WARNING_MESSAGE in rxDict:
            warning_message = rxDict[GUIServer.WARNING_MESSAGE]
            ui.notify(warning_message, type="warning")

    def _persistent_notify(self, message: str):
        with ui.dialog() as dialog, ui.card():
            ui.label(message)
            with ui.row().classes('w-full justify-center'):
                ui.button('OK', on_click=dialog.close)
        dialog.open()

    def _init_eddi_tab(self):
        """@brief Init the tab used for access to EDDI stats and control."""
        with ui.row().style(GUIServer.TEXT_STYLE_A):
            with ui.column():
                ui.label("Tank")
                ui.label("Top")
                ui.label("Bottom")
            with ui.column():
                ui.label('°C')
                self._w._topTankTempLabel = ui.label("").style(GUIServer.TEXT_STYLE_B)
                self._w._bottomTankTempLabel = ui.label("").style(GUIServer.TEXT_STYLE_B)
        html.hr()

        with ui.row():
            ui.label('Boost Until').style(GUIServer.TEXT_STYLE_A)

        with ui.row().classes('w-full'):
            self._w._bootMinsSlider = ui.slider(min=15, max=240, value=15, step=15)
            self._w._bootMinsSlider.on('update:model-value', self._update_boost_time)
            # We call a method to convert the slider value in minutes to a boost until time.
            ui.label().bind_text_from(self._w, '_boost_time_value').style(GUIServer.TEXT_STYLE_B)
            self._update_boost_time()

        with ui.row():
            ui.label('Boost Control').style(GUIServer.TEXT_STYLE_A)

        with ui.row():
            self._w._boost_top_button = ColorButton(self._top_boost, 'Top').style("width: 100px; "+GUIServer.TEXT_STYLE_A_SIZE)
            self._w._boost_bottom_button = ColorButton(self._bottom_boost, 'Bottom').style("width: 100px; "+GUIServer.TEXT_STYLE_A_SIZE)
            # Set the mid color to yellow when heater is powered from the sun.
            self._w._boost_top_button.set_button_colors(["blue", 'yellow', 'green'])
            self._w._boost_bottom_button.set_button_colors(["blue", 'yellow', 'green'])
            self._w._boost_stop_button = ColorButton(self._stop_boost, 'Off').style("width: 100px; "+GUIServer.TEXT_STYLE_A_SIZE)
            self._w._buttonList.append(self._w._boost_top_button)
            self._w._buttonList.append(self._w._boost_bottom_button)
            # We don't add the _boost_stop_button to this list so that we can always issue a stop boost command
            # as the button will never be disabled.

    def _update_boost_time(self):
        """@brief Called to update the boost until time."""
        dt = datetime.now().astimezone()
        dt = dt + timedelta(minutes=self._w._bootMinsSlider.value)
        mins_to_add = 15 - (dt.minute % 15)
        dt = dt + timedelta(minutes=mins_to_add)
        self._w._boost_time_value = f"{dt.hour:02d}:{dt.minute:02d}"
        self._w._boost_until_datetime = dt.replace(second=0, microsecond=0)

    def _enable_buttons(self, enabled):
        for _button in self._w._buttonList:
            if enabled:
                _button.enable()
            else:
                _button.disable()

    def _top_boost(self):
        """@brief Turn on the top tank boost"""
        self._update_boost_time()
        self._eddi_heater_button_selected = 1
        self._enable_buttons(True)
        ui.notify("Setting top boost on.", position='center')
        threading.Thread(target=self._set_boost, args=(True, MyEnergi.TANK_TOP, self._w._boost_until_datetime)).start()
        self._reset_polling_rate()

    def _bottom_boost(self):
        """@brief Turn on the bottom tank boost"""
        self._update_boost_time()
        self._eddi_heater_button_selected = 2
        self._enable_buttons(True)
        ui.notify("Setting bottom boost on.", position='center')
        threading.Thread(target=self._set_boost, args=(True, MyEnergi.TANK_BOTTOM, self._w._boost_until_datetime)).start()
        self._reset_polling_rate()

    def _stop_boost(self):
        """@brief disable all tank boost schedules."""
        self._update_boost_time()
        self._eddi_heater_button_selected = 0
        self._enable_buttons(True)
        ui.notify("Turning off boost.", position='center')
        threading.Thread(target=self._set_boost, args=(False, None, None)).start()
        self._reset_polling_rate()
        # The schedule is being removed now so there is no need to clear it later.
        self._cfg_mgr.addAttr(GUIServer.CLEAR_EDDI_SCHEDULE_TIME, "")
        self._store_config()

    def _update_gui(self, msg_dict):
        """@brief Send a message to the GUI to update it.
           @param msg_dict A dict containing details of how to update the GUI."""
        # Record the seconds when we received the message
        msg_dict[GUIServer.GUI_POLL_SECONDS] = time()
        # Send to every connected browser. If none are connected the message is dropped
        # (previously it would sit in the queue for ever).
        for view in list(self._client_views.values()):
            view.queue.put(msg_dict)

    def _previous_quarter_hour(self, dt):
        """@brief Get a datetime instance that is aligned with the a quarter hour starting just before the current one."""
        # Subtract the number of mins
        spare_mins = dt.minute % 15
        new_minute = dt.minute - spare_mins
        rounded_time = dt.replace(minute=new_minute, second=0, microsecond=0)
        return rounded_time

    def _set_boost(self, on, relay, on_until_time):
        """@brief Called in a separate thread to talk to the eddi unit and set the hot water boost state.
                  We don't use the boost command because of the way the eddi works in boost mode. If boost
                  mode is set on and the thermostat in the hot water tank heater disconnects the heater
                  element the eddi assumes the hot water tank temperature has been reached and the boost
                  is halted. This may mean the target tank temperature is not reached.

                  The scheduled timers are set to turn on the heater for a predetermined time. If the
                  thermostat in the hot water tank heater disconnects the heater element then the hot
                  water stops heating as it should. If, subsequentally, the thermostat reconnects the
                  heating element and it is still withing the scheduled time then the hot water will
                  resume heating the water if the tank temperature is yet to be reached.

                  We reserve the 4'th timer for this purpose. 10 minutes after the schedule has
                  finished the schedule is removed from the schedule list.

           @param on If True turn boost on. If False turn boost off on both top and bottom tanks.
           @param relay 1 = top tank relay, 2 = bottom tank relay.
           @param on_until_time A datetime instance that details when the hot water heating element
                                should be turned off (if on=True).
           """
        try:
            self._set_boost_inner(on, relay, on_until_time)
        except Exception as ex:
            GUIServer.Print_Exception()
            msg_dict = {}
            msg_dict[GUIServer.ERROR_MESSAGE] = str(ex)
            self._update_gui(msg_dict)

    def _set_boost_inner(self, on, relay, on_until_time):
        """@brief See _set_boost(). Any exception raised here is reported to the GUI."""
        self._debug(f"set_boost(on={on}, relay={relay}, on_until_time={on_until_time})")
        if on:
            now = datetime.now().astimezone()
            schedule_start_time = self._previous_quarter_hour(now)
            schedule_duration = on_until_time - schedule_start_time
            self._debug(f"schedule_start_time={schedule_start_time}, schedule_duration={schedule_duration}")
            on_time = on_until_time - now
            heater_name = "top"
            if relay == 2:
                heater_name = "bottom"
            seconds = on_time.seconds
            msg_dict = {}
            minutes = seconds / 60
            hours = int(minutes / 60)
            minutes = int(minutes-(hours*60))
            msg_dict[GUIServer.INFO_MESSAGE] = f"The {heater_name} tank heater should turn on for {hours:02d}:{minutes:02d}"
            self._update_gui(msg_dict)

            # Send the schedule to the eddi
            self._my_energi.set_tank_schedule(on, schedule_start_time, schedule_duration, relay)

            # Set the delete schedule time to be 10 minutes after the tank heating  finishes. 10 minutes was chosen
            # as I've seen the myenergi system take up to 5 minutes to delete a schedule after sending a
            # successfull command. We want to have it clear before then next 15 minute slot.
            clear_schedule_time = on_until_time + timedelta(minutes=10)
            self._cfg_mgr.addAttr(GUIServer.CLEAR_EDDI_SCHEDULE_TIME, clear_schedule_time.strftime("%Y-%m-%dT%H:%M:%SZ"))
            # Save now so the schedule is still cleared if the app restarts before the boost ends.
            self._store_config()
            self._debug(GUIServer.CLEAR_EDDI_SCHEDULE_TIME + f"={clear_schedule_time}")

        else:
            self._my_energi.set_water_tank_boost_schedules_off()
            msg_dict = {}
            msg_dict[GUIServer.INFO_MESSAGE] = "Set boost schedule off."
            self._update_gui(msg_dict)

    def _is_eddi_config_entered(self):
        """@return True if the eddi config has been entered."""
        eddi_config_set = False
        api_key = self._cfg_mgr.getAttr(GUIServer.MYENERGI_API_KEY)
        eddi_serial_number = self._cfg_mgr.getAttr(GUIServer.EDDI_SERIAL_NUMBER)
        if api_key and \
           len(api_key) > 0 and \
           eddi_serial_number and \
           len(eddi_serial_number) > 0:
            eddi_config_set = True
        return eddi_config_set

    def _update_stats(self):
        """@brief Update the stats read from the network.
                  This should not be called in the GUI thread as it will block if there are network issues."""
        try:
            if self._is_eddi_config_entered():
                self._my_energi.update_stats()
                top_temp = self._my_energi.get_eddi_top_tank_temp()
                bottom_temp = self._my_energi.get_eddi_bottom_tank_temp()
                self._heater_load_watts = self._my_energi.get_eddi_heater_watts()
                try:
                    self._zappi_charge_watts = self._my_energi.get_zappi_charge_watts()
                except Exception:
                    zappi_serial_number = self._cfg_mgr.getAttr(GUIServer.ZAPPI_SERIAL_NUMBER)
                    # If the zappi serial number has been set raise an errror to show to the user as
                    # we shopuld be able to communicate with the zappi charger.
                    if len(zappi_serial_number) > 0:
                        raise
                self._relay_on = self._my_energi.get_eddi_heater_number()
                msg_dict = {}
                msg_dict[GUIServer.TANK_TEMPERATURES] = [top_temp, bottom_temp]
                self._update_gui(msg_dict)
        except Exception as ex:
            GUIServer.Print_Exception()
            msg_dict = {}
            msg_dict[GUIServer.ERROR_MESSAGE] = str(ex)
            self._update_gui(msg_dict)

    def _init_settings_tab(self):
        """@brief Init the tab used to hold app settings."""
        with ui.row():
            self._w._api_key = ui.input(label='myenergi API Key').style("width: 300px; "+GUIServer.TEXT_STYLE_A_SIZE)
        with ui.row():
            self._w._eddi_serial_number = ui.input(label='eddi serial number').style("width: 300px; "+GUIServer.TEXT_STYLE_A_SIZE)
        with ui.row():
            self._w._zappi_serial_number = ui.input(label='zappi serial number').style("width: 300px; "+GUIServer.TEXT_STYLE_A_SIZE)
        with ui.row():
            self._w._zappi_max_charge_rate = ui.select(options=["7.4", "22"],
                                                       value="7.4",
                                                       with_input=True,
                                                       label='Zappi charge rate')

        with ui.row():
            kwh = self._cfg_mgr.getAttr(GUIServer.EV_BATTERY_KWH)
            self._w._ev_kwh = ui.number(label='EV Battery (kWh)', value=kwh, format='%.1f')

        with ui.row():
            self._w._electricity_region_code = ui.select(options=RegionalElectricity.VALID_REGION_CODE_LIST_WITH_REGIONS,
                                                         value=RegionalElectricity.VALID_REGION_CODE_LIST_WITH_REGIONS[0],
                                                         with_input=True,
                                                         label='Electricity region code')

        with ui.row():
            self._w._tariff_radio = ui.radio(GUIServer.TARIFF_LIST,
                                             on_change=self._tariff_changed,
                                             value=GUIServer.TARIFF_LIST[0])

        with ui.row():
            # A plot of energy costs is added to this container when the users requests it
            self._w._other_tariff_plot_container = ui.element('div')

        with ui.row():
            self._w._undershoot_checkbox = ui.checkbox('Undershoot').tooltip("Charge times are in 15 min increments. Therefore the charge may be slightly longer "
                                                                             "than is required to reach the target charge. If checked then the battery may be up to 15 mins under charged.")

        with ui.row():
            self._w._add_tariff_value_button = ui.button('Add', color=GUIServer.DEFAULT_BUTTON_COLOR, on_click=self._add_tariff_value)
            self._w._clear_tariff_value_button = ui.button('Clear', color=GUIServer.DEFAULT_BUTTON_COLOR, on_click=self._clear_tariff)

        with ui.row():
            self._w._config_save_button = ui.button('Save', color=GUIServer.DEFAULT_BUTTON_COLOR, on_click=self._save_config_button_selected)

        self._w._api_key.value = self._cfg_mgr.getAttr(GUIServer.MYENERGI_API_KEY)
        self._w._eddi_serial_number.value = self._cfg_mgr.getAttr(GUIServer.EDDI_SERIAL_NUMBER)
        self._w._zappi_serial_number.value = self._cfg_mgr.getAttr(GUIServer.ZAPPI_SERIAL_NUMBER)
        self._w._zappi_max_charge_rate.value = self._cfg_mgr.getAttr(GUIServer.ZAPPI_MAX_CHARGE_RATE)
        self._w._electricity_region_code.value = self._cfg_mgr.getAttr(GUIServer.ELECTRICITY_REGION_CODE)
        self._octopus_agile_tariff = self._cfg_mgr.getAttr(GUIServer.OCTOPUS_AGILE_TARIFF)
        self._set_octopus_agile_tariff(self._octopus_agile_tariff)
        self._enable_octopus_agile_tariff(self._octopus_agile_tariff)
        self._w._undershoot_checkbox.value = self._cfg_mgr.getAttr(GUIServer.UNDERSHOOT_CHARGE)

    async def _save_config_button_selected(self):
        """@brief Called when the save button is selected by the user in the Setting tab."""
        save_button = self._w._config_save_button
        save_button.disable()
        try:
            if await self._save_settings():
                # Create a new instance of the interface to talk to the myenergi products
                self._create_myenergi()
        finally:
            save_button.enable()

    def _set_octopus_agile_tariff(self, enabled):
        """@brief Set the radio buttons to enable the octopus agile tariff or the other (manually entered) tariff."""
        if enabled:
            self._w._tariff_radio.value = GUIServer.TARIFF_LIST[0]
        else:
            self._w._tariff_radio.value = GUIServer.TARIFF_LIST[1]

    def _enable_octopus_agile_tariff(self, enabled):
        """@brief Called when the octopus agile tariff is enabled."""
        if enabled:
            self._w._add_tariff_value_button.disable()
            self._w._clear_tariff_value_button.disable()
        else:
            self._w._add_tariff_value_button.enable()
            self._w._clear_tariff_value_button.enable()

    def _tariff_changed(self):
        """@brief Called when the tariff radio button is selected."""
        octopus_agile_tariff = self._is_octopus_agile_tariff_enabled()
        self._enable_octopus_agile_tariff(octopus_agile_tariff)
        if octopus_agile_tariff:
            self._w._add_tariff_value_button.disable()
            self._w._clear_tariff_value_button.disable()
            if self._w._other_tariff_plot_container:
                self._w._other_tariff_plot_container.clear()

        else:
            self._w._add_tariff_value_button.enable()
            self._w._clear_tariff_value_button.enable()
            # We only display the other tarrif plot as the agile tariff will change
            self._plot_tariff()

    def _add_tariff_value(self):
        """@brief Add a tariff value to the displayed other tariff."""
        self._w._add_tariff_dialog = YesNoDialog("Add one tariff point.",
                                                 self._tariff_value_entered,
                                                 successButtonText="OK",
                                                 failureButtonText="Cancel")
        self._w._add_tariff_dialog.addField(GUIServer.ADD_TARIFF_START_TIME, YesNoDialog.HOUR_MIN_INPUT_FIELD_TYPE)
        self._w._add_tariff_dialog.addField(GUIServer.ADD_TARIFF_PRICE, YesNoDialog.NUMBER_INPUT_FIELD_TYPE, minNumber=0, maxNumber=2, step=0.01)
        self._w._add_tariff_dialog.show()

    def _calc_cost_initial_step(self):
        """@brief Octopus Energy (and maybe other providers) currently send notifications to some customers (in areas that have high levels of green energy)
                  that they can have periods of time with free energy (Octopus Energy refer to these as 'Power Ups').
                  If the user selected the 'Free energy period' dialog then the user can enter the up coming free energy period so that the calculation of
                  the optimal charge time takes this into account."""
        if self._w._free_energy_checkbox.value:
            self._w._add_free_elect_period_dialog = YesNoDialog("Add free energy period.",
                                                                self._free_period_entered,
                                                                successButtonText="OK",
                                                                failureButtonText="Cancel")
            self._w._add_free_elect_period_dialog.addField(GUIServer.ZERO_COST_ELEC_START_TIME, YesNoDialog.HOUR_MIN_INPUT_FIELD_TYPE)
            self._w._add_free_elect_period_dialog.addField(GUIServer.ZERO_COST_ELEC_DURATION, YesNoDialog.HOUR_MIN_INPUT_FIELD_TYPE)
            self._w._add_free_elect_period_dialog.show()
        else:
            self._calc_optimal_charge_times()

    def _free_period_entered(self):
        """@brief Called if the user enters a period of time when they should get free energy. E.G Octopus 'Power Ups'"""
        start_time = self._w._add_free_elect_period_dialog.getValue(GUIServer.ZERO_COST_ELEC_START_TIME)
        duration = self._w._add_free_elect_period_dialog.getValue(GUIServer.ZERO_COST_ELEC_DURATION)
        self._calc_optimal_charge_times(free_start_time=start_time, free_duration=duration)

    def _get_hour_min(self, tstr):
        """@brief Get the hour and min from a single tariff point.
           @return A tuple containing
                   0 = hour
                   1 = min"""
        hour = -1
        min = -1
        elems = tstr.split(':')
        if len(elems) == 2:
            try:
                hour = int(elems[0])
                min = int(elems[1])
            except ValueError:
                pass
        if hour == -1 or min == -1:
            raise Exception(f"{tstr} is invalid (HH:MM expected).")
        return (hour, min)

    def _tariff_value_entered(self):
        start_time = self._w._add_tariff_dialog.getValue(GUIServer.ADD_TARIFF_START_TIME)
        price = self._w._add_tariff_dialog.getValue(GUIServer.ADD_TARIFF_PRICE)
        try:
            if start_time and len(start_time) > 0 and price > 0.0:
                hour, min = self._get_hour_min(start_time)
                # If this is the first tariff data then it must start at the start of the day.
                if len(self._other_tariff_values) == 0 and (hour != 0 or min != 0):
                    raise Exception("The first tariff value must start at 00:00 (HH:MM).")

                if len(self._other_tariff_values) > 0:
                    this_hour, this_min = self._get_hour_min(start_time)
                    last_hour, last_min = self._get_hour_min(self._other_tariff_values[-1][0])
                    in_seq = False
                    if last_hour < this_hour:
                        in_seq = True

                    elif last_hour == this_hour:
                        if last_min < this_min:
                            in_seq = True

                    if not in_seq:
                        raise Exception(f"tariff list is not ascending ({this_hour:02d}:{this_min:02d} is not after the previous one, {last_hour:02d}:{last_min:02d}).")

                tariff_point = (start_time, price)
                # PJA Add checks for duplicate start times
                self._other_tariff_values.append(tariff_point)
                self._plot_tariff()

        except Exception as ex:
            GUIServer.Print_Exception()
            ui.notify(f"{str(ex)}", type='negative')

    def _get_tariff(self):
        """@brief get a list of the tariff string values converted to datetime instances.
           @return tariff_datetime_list A list. Each element has two elements.
                   0: A datetime instance at incrementing times during the day.
                   1: The price of the electricity at that point in the day."""
        if len(self._other_tariff_values) == 0:
            raise Exception("Use the add button in the settings tab to set the tariff values through the day.")

        # Convert the tariff times into datetime instances
        tariff_list = []
        index = 0
        for other_tariff_value in self._other_tariff_values:
            hour, min = self._get_hour_min(other_tariff_value[0])
            price = other_tariff_value[1]
            dt = datetime.now().astimezone()
            dt = dt.replace(minute=min, hour=hour, second=0, microsecond=0)
            # Check the datetime is not in the list twice
            if dt in tariff_list:
                raise Exception(f"{hour:02d}:{min:02d} is in the tariff list twice.")

            tariff_list.append((deepcopy(dt), price))
            index = index + 1
        return tariff_list

    def _get_price(self, _datetime):
        """@brief Get the price of the electricity at the given time.
           @param _datetime The datetime of interest.
           @return The price of electricity per kWh at the given time of day or None if no tariff data is available."""
        tariff_data = self._get_tariff()
        if tariff_data and len(tariff_data) > 0:
            price = tariff_data[0][1]
            for data in tariff_data:
                dt = data[0]

                if _datetime.hour < dt.hour:
                    break
                elif _datetime.hour == dt.hour and _datetime.minute < dt.minute:
                    break

                price = data[1]
        return price

    def _plot_tariff(self):
        """@brief Plot the available tariff data."""
        try:
            ui.notify("Plotting the tariff data.", position='center', type='ongoing', timeout=2000)
            now = datetime.now().astimezone()
            start_of_this_day = now.replace(minute=0, hour=0, second=0)
            # Get a value for every 1/2 hour through the day
            time_intervals = [start_of_this_day + timedelta(minutes=30 * i) for i in range((24*2))]
            price_list = []
            for time_interval in time_intervals:
                price = self._get_price(time_interval)
                price_list.append(price)

            prices = price_list

            fig = go.Figure()
            max_cost = max(prices)
            fig.update_layout(margin=dict(l=0, r=0, t=0, b=0),
                              width=350,
                              height=150,
                              showlegend=False,
                              plot_bgcolor="black",       # Background for the plot area
                              paper_bgcolor="black",      # Background for the entire figure
                              font=dict(color="yellow"),  # Font color for labels and title
                              xaxis=dict(
                                  title='Day (HH:MM)',
                                  tickformat='%H:%M',     # Format as hours:minutes
                                  color="yellow",         # Axis label color
                                  gridcolor="gray",       # Gridline color
                                  zerolinecolor="gray"    # Zero line color
                              ),
                              yaxis=dict(
                                  title="£ per kWh",
                                  color="yellow",         # Axis label color
                                  gridcolor="gray",       # Gridline color
                                  zerolinecolor="gray",   # Zero line color
                                  range=[0, max_cost*1.5]
                              ),)
            fig.add_trace(go.Bar(x=time_intervals, y=prices, marker=dict(color='green')))
            if self._w._other_tariff_plot_container:
                self._w._other_tariff_plot_container.clear()
                # Add the new plot to the container
                with self._w._other_tariff_plot_container:
                    ui.plotly(fig)

        except Exception as ex:
            GUIServer.Print_Exception()
            ui.notify(f"{str(ex)}", type='negative')

    def _clear_tariff(self):
        """@brief Clear the other tariff values."""
        self._other_tariff_values = []
        if self._w._other_tariff_plot_container:
            self._w._other_tariff_plot_container.clear()

    @staticmethod
    def CHECK_EDDI_ACCESS(api_key, eddi_serial_number):
        """@brief Check that the stats can be read from the myenergi eddi unit.
                  This accesses the network so should not be called in the GUI thread.
           @return None if OK, else an error message."""
        try:
            my_energi = MyEnergi(api_key)
            my_energi.set_eddi_serial_number(eddi_serial_number)
            my_energi.get_eddi_stats()
            return None
        except Exception as ex:
            GUIServer.Print_Exception()
            return str(ex)

    @staticmethod
    def CHECK_ZAPPI_ACCESS(api_key, eddi_serial_number, zappi_serial_number):
        """@brief Check that the stats can be read from the myenergi zappi unit.
                  This accesses the network so should not be called in the GUI thread.
           @return None if OK, else an error message."""
        try:
            my_energi = MyEnergi(api_key)
            my_energi.set_eddi_serial_number(eddi_serial_number)
            my_energi.set_zappi_serial_number(zappi_serial_number)
            my_energi.get_zappi_stats()
            return None
        except Exception as ex:
            GUIServer.Print_Exception()
            return str(ex)

    def _show_regional_codes(self):
        """@brief Show the regional electricity codes.
                  Not used."""
        ui.html('<style>.multi-line-notification { white-space: pre-line; }</style>')
        ui.notify(
            'A 	Eastern England. \n'
            'B 	East Midlands \n'
            'C 	London \n'
            'D 	North Wales, Merseyside and Cheshire \n'
            'E 	West Midlands \n'
            'F 	North East England \n'
            'G 	North West England \n'
            'H 	Southern England \n'
            'J 	South East England \n'
            'K 	South Wales \n'
            'L 	South West England \n'
            'M 	Yorkshire \n'
            'N 	Southern Scotland \n'
            'P 	Northern Scotland \n',
            multi_line=True,
            classes='multi-line-notification',
            position='center'
        )

    def _init_zappi_tab(self):
        """@brief Init the tab used for access to ZAPPI stats and control."""

        with ui.row().classes('w-full'):
            with ui.row().classes('w-full'):
                ui.label('Target EV charge (%)')
                self._w._target_ev_charge_input = ui.number(min=5, max=100, value=0).style(GUIServer.TEXT_STYLE_D_SIZE)
            self._w._target_ev_charge_input.value = self._cfg_mgr.getAttr(GUIServer.TARGET_EV_CHARGE_PERCENTAGE)

        with ui.row().classes('w-full'):
            with ui.row().classes('w-full'):
                ui.label('Current EV charge (%)')
                self._w._current_ev_charge_input = ui.number(min=0, max=100, value=0).style(GUIServer.TEXT_STYLE_D_SIZE)
            self._w._current_ev_charge_input.value = self._cfg_mgr.getAttr(GUIServer.CURRENT_EV_CHARGE_PERCENTAGE)

        # Put this off the bottom of the mobile screen as most times it will not be needed
        # and there is not enough room on the mobile screen above the plot pane.
        self._w._end_charge_time_input = self._get_input_time_field('Ready by')
        self._w._end_charge_time_input.value = self._cfg_mgr.getAttr(GUIServer.READY_BY)

        self._w._free_energy_checkbox = ui.checkbox('Free energy period')

        with ui.row():
            # A plot of energy costs is added to this container when the users requests it
            self._w._plot_container = ui.element('div')

        with ui.row():
            self._w._calc_button = ColorButton(self._calc_cost_initial_step, 'Calc')
            self._w._calc_button.tooltip("Calculate the optimal charge time/s.")
            self._w._set_button = ColorButton(self._set_zappi_charge, 'Set')
            self._w._set_button.tooltip('Set the displayed charge schedule on your zappi charger.')
            self._w._get_button = ColorButton(self._get_zappi_charge, 'Get')
            self._w._get_button.tooltip('Get the current charge schedule on your zappi.')

            self._w._clear_zappi_button = ColorButton(self._clear_zappi_charge_schedules, 'Clear')
            self._w._clear_zappi_button.tooltip('Clear all charge schedules from your zappi charger.')

    def _get_zappi_charge(self):
        """@brief Get the current zappi charge schedule."""
        ui.notify("Reading the zappi charge shedules.")
        threading.Thread(target=self._get_zappi_charge_thread).start()

    def _send_zappi_sched_to_gui(self, table_row_list):
        """@brief After having read the zappi schedule list from the myenergi system
                  send it to the GUI.
           @param table_row_list A list of rows to add to the zappi charge table."""
        msg_dict = {}
        msg_dict[GUIServer.ZAPPI_CHARGE_SCHEDULE] = table_row_list
        self._update_gui(msg_dict)

    def _get_zappi_charge_thread(self):
        """@brief Read the zappi charge """
        try:
            table_row_list = self._my_energi.get_zappi_schedule_list()

            msg_dict = {}
            msg_dict[GUIServer.INFO_MESSAGE] = "Read the zappi charge shedules."
            self._update_gui(msg_dict)
            self._send_zappi_sched_to_gui(table_row_list)

        except Exception as ex:
            GUIServer.Print_Exception()
            msg_dict = {}
            msg_dict[GUIServer.ERROR_MESSAGE] = str(ex)
            self._update_gui(msg_dict)

    def _set_zappi_charge_active(self, active):
        """@brief Set the indicator to the user that shows that the zappi charge is active/inactive.
           @param active If True then a zappi charge schedule has been set."""
        self._zappi_charge_schedule_active = active

    def _display_zappi_charge_table(self, zappi_charge_sched_table):
        """@brief Display the table of configured zappi charge schedules.
           @param zappi_charge_sched_table A list of rows in the zappi charge schedule table."""
        # If we have somewhere to display the table.
        if self._w._plot_container:
            # Clear it's current contents.
            self._w._plot_container.clear()
            # Add the table to the displayed gui
            with self._w._plot_container:
                columns = [
                    {'name': 'Time', 'label': 'Time', 'field': 'Time', 'required': True, 'align': 'left'},
                    {'name': 'Duration', 'label': 'Duration', 'field': 'Duration', 'sortable': True},
                    {'name': 'Days', 'label': 'Days', 'field': 'Days', 'sortable': True},
                ]
                rows = []
                for row in zappi_charge_sched_table:
                    rows.append({'Time': row[0], 'Duration': row[1], 'Days': row[2]})
                ui.table(columns=columns, rows=rows, row_key='name')

        ui.timer(once=True, interval=2.0, callback=self._show_get_msg_delay)

    def _show_get_msg_delay(self):
        """@brief Show  messge to indicate to the user it may take a while before the
                  myenergi zappi schedule is updated."""
        ui.notify("The myenergi zappi schedule may take several mins to update after it has been set.")

    def _get_input_time_field(self, label):
        """@brief Add a control to allow the user to enter the time as an hour and min.
           @param label The label for the time field.
           @return The input field containing the hour and minute entered."""
        # Put this off the bottom of the mobile screen as most times it will not be needed
        # and there is not enough room on the mobile screen above the plot pane.
        with ui.row().classes('w-full'):
            ui.label(label)
            time_input = ui.input("(HH:MM)").style("width: 250px; "+GUIServer.TEXT_STYLE_E_SIZE)
            with time_input as time:
                with ui.menu().props('no-parent-event') as menu:
                    with ui.time().bind_value(time):
                        ui.button('Close', color=GUIServer.DEFAULT_BUTTON_COLOR, on_click=menu.close).props('flat')
                with time.add_slot('append'):
                    ui.icon('access_time').on('click', menu.open).classes('cursor-pointer')
        return time_input

    def _get_end_charge_time(self):
        """@brief Get the end charge time.
           @return A tuple
                   0 = Hours
                   1 = mins"""
        return self._get_hours_mins(self._w._end_charge_time_input.value)

    def _get_hours_mins(self, text):
        """@brief Get the hours and minutes from a string.
           @param text The text in HH:MM format.
           @return A tuple
                   0 = Hours
                   1 = mins

                   o None if not valid."""
        hours = None
        mins = None
        if text and len(text) >= 3:
            elems = text.split(':')
            if len(elems) == 2:
                hours_str = elems[0]
                mins_str = elems[1]
                try:
                    hours = int(hours_str)
                    mins = int(mins_str)
                except ValueError:
                    pass

        if hours is not None and mins is not None:
            return (hours, mins)

        return None

    def _calc_optimal_charge_times(self, free_start_time="", free_duration=""):
        """@brief Calculate the optimal charge times."""

        free_start_time_hh_mm = self._get_hours_mins(free_start_time)
        free_duration_hh_mm = self._get_hours_mins(free_duration)

        self._save_charge_fields()

        current_ev_charge_percentage = float(self._w._current_ev_charge_input.value)
        target_ev_charge_percentage = float(self._w._target_ev_charge_input.value)
        if target_ev_charge_percentage > 100:
            ui.notify("The target EV charge cannot be greater than 100 %.", type='negative')
            return

        # Define the target as a float at the top end of the value.
        target_ev_charge_percentage = float(int(self._w._target_ev_charge_input.value)) + 0.99

        ev_battery_kwh = self._w._ev_kwh.value

        if ev_battery_kwh <= 0.0:
            ui.notify("Please set an EV battery capacity greater than 0 in the settings tab.", type='negative')
            return

        target_charge_factor = target_ev_charge_percentage/100.0
        current_charge_factor = current_ev_charge_percentage/100.0

        if current_charge_factor > 1.0:
            ui.notify("The current EV charge cannot be greater than 100 %.", type='negative')
            return

        # If the current charge factor is greater than is already present in the battery
        if current_charge_factor >= target_charge_factor:
            ui.notify(f"The current charge ({current_ev_charge_percentage:.1f} %) is greater than target charge of {target_ev_charge_percentage:.1f} %.", type='negative')
            return

        required_charge_factor = float(target_charge_factor - current_charge_factor)
        charge = required_charge_factor * float(ev_battery_kwh)

        charge_time_mins = 0
        if charge == 0 and charge_time_mins == 0 or \
           charge != 0 and charge_time_mins != 0:
            ui.notify("You must set either the charge or charge time greater than 0.", type='negative')
            return

        if charge > 0:
            charge_time_mins = int((charge/float(self._w._zappi_max_charge_rate.value))*60)
            # Ensure a multiple of 15 mins as we don't want to be turning the charger on/off
            # any more quickly than this. MyEnergi only allows charge times in chunks of 15 mins.
            remainder = charge_time_mins % 15
            if remainder > 0:
                charge_time_mins = charge_time_mins - remainder
                if not self._w._undershoot_checkbox.value:
                    # Round up to 15 min intervals. This should mean that the EV charge is least at the required charge level.
                    # Worst case we charge almost 15 mins longer than is needed to reach the required charge level.
                    charge_time_mins += 15

        if charge_time_mins <= 0:
            ui.notify("The charge time is too short to reach a 15 min charge slot.", type='negative')

        else:
            region_code = self._get_region_code()
            ui.notify("Calculating optimal charge time/s.", position='center', type='ongoing', timeout=1000)
            threading.Thread(target=self.calc_optimal_charge_times_thread, args=(region_code,
                                                                                 charge_time_mins,
                                                                                 float(self._w._zappi_max_charge_rate.value),
                                                                                 self._get_end_charge_time(),
                                                                                 free_start_time_hh_mm,
                                                                                 free_duration_hh_mm,
                                                                                 self._is_octopus_agile_tariff_enabled())).start()

    def _get_region_code(self):
        """@brief Get the electricity region code.
           @return The single letter electricity region code or None if not set."""
        region_code = self._w._electricity_region_code.value
        if region_code:
            elems = region_code.split()
            region_code = elems[0]
        return region_code

    @staticmethod
    def GET_END_CHARGE_DATETIME(end_charge_time):
        """@brief Get the end charge time as a datetime instance.
           @param end_charge_time The time (a tuple hours,mins) at which the charging must have completed or None if no charge time defined.
           @return The next occurrence of that time (today if still to come, else tomorrow) or None."""
        end_charge_datetime = None
        if end_charge_time:
            now = datetime.now().astimezone()
            end_charge_datetime = now.replace(hour=end_charge_time[0], minute=end_charge_time[1], second=0, microsecond=0)
            # If the time has already passed today then it must be tomorrow.
            if end_charge_datetime <= now:
                end_charge_datetime = end_charge_datetime + timedelta(days=1)
        return end_charge_datetime

    def _get_tariff_data(self, end_charge_time):
        """@brief Get the tariff data needed to calculate the best charge times when not
                  one octopus agile tariff.
           @param end_charge_time The time (a tuple hours,mins) at which the charging must have completed."""
        start_datetime = RegionalElectricity.GET_NEXT_30_MIN_TIME()
        # Get a value for every 1/2 hour through the day and into the next
        time_intervals = [start_datetime + timedelta(minutes=30 * i) for i in range((48*2))]

        # If the end charge time is defined then ensure we don't have time after this in the list.
        if end_charge_time:
            then = GUIServer.GET_END_CHARGE_DATETIME(end_charge_time)

            tmp_time_intervals = []
            for time_interval in time_intervals:
                # Stop at the first slot that would finish after the end charge time
                if time_interval + timedelta(minutes=30) > then:
                    break
                tmp_time_intervals.append(time_interval)
            time_intervals = tmp_time_intervals

        price_list = []
        for time_interval in time_intervals:
            price = self._get_price(time_interval)
            price_list.append(price)

        return (time_intervals, price_list)

    def _update_free_periods(self,
                             free_start_time_hh_mm,
                             free_duration_hh_mm,
                             plot_time_stamp_list,
                             plot_cost_list):
        """@brief UPdate the tariff periods with any free energy periods.
           @param free_start_time_hh_mm A tuple containing HH, MM of the start time of a free energy period or None if no free energy period is available.
           @param free_duration_hh_mm A tuple containing HH, MM of the duration of a free energy period or None if no free energy period is available.
           @param plot_time_stamp_list A list of the tariff times.
           @param plot_cost_list A list of the tariff costs."""

        # If the user has entered a period of time when they will get free energy
        if free_start_time_hh_mm and free_duration_hh_mm:
            # Update the tariff values with the zero cost energy times.
            free_start_time = None
            free_stop_time = None
            for index in range(0, len(plot_time_stamp_list)):
                ts = plot_time_stamp_list[index]
                if ts.hour == free_start_time_hh_mm[0]:
                    # We assume that the HH:MM entered by the user is the next HH:MM that come round.
                    free_start_time = plot_time_stamp_list[index].replace(hour=free_start_time_hh_mm[0], minute=free_start_time_hh_mm[1], second=0, microsecond=0)
                    free_stop_time = free_start_time + timedelta(hours=free_duration_hh_mm[0], minutes=free_duration_hh_mm[1])
                    break

            # If we have a free energy period
            if free_start_time and free_stop_time:
                # Set the cost of energy in this period to 0
                for index in range(0, len(plot_time_stamp_list)):
                    ts = plot_time_stamp_list[index]
                    if ts >= free_start_time and ts <= free_stop_time:
                        plot_cost_list[index] = 0.0

    def _get_charge_details(self,
                            charge_mins,
                            end_charge_time,
                            charge_rate_kw,
                            region_code,
                            free_start_time_hh_mm,
                            free_duration_hh_mm,
                            octopus_agile_tariff):
        """@brief Get the requested charge details.
           @param charge_mins The required charge time in mins.
           @param end_charge_time The time (a tuple hours,mins) at which the charging must have completed.
           @param charge_rate_kw The rate at which the charger will charge the EV in kW.
           @param region_code The regional electricity code.
           @param free_start_time_hh_mm A tuple containing HH, MM of the start time of a free energy period or None if no free energy period is available.
           @param free_duration_hh_mm A tuple containing HH, MM of the duration of a free energy period or None if no free energy period is available.
           @param octopus_agile_tariff True if the Octopus Agile tariff is selected (read in the GUI thread).
           @return A tuple containing
                   0: A list of charge details dicts.
                   1: The end charge time (datetime instance)
                   2: A list of the charge slot start times.
                   3: A list of the costs for each charge slot.
                   4: The total charge time in mins.
                   5: The total charge cost"""
        if octopus_agile_tariff:
            # Display a message to the user if they attempt to charge before 16:00
            now = datetime.now().astimezone()
            then = now.replace(hour=16, minute=0, second=0, microsecond=0)
            if now < then:
                msg_dict = {}
                msg_dict[GUIServer.WARNING_MESSAGE] = "You may want to wait until shortly after 16:00. Tomorows Agile prices will then be available."
                self._update_gui(msg_dict)

            regional_electricity = RegionalElectricity(self._uio)
            plot_time_stamp_list, plot_cost_list, end_charge_datetime = regional_electricity.get_prices(region_code, end_charge_time)
            if len(plot_time_stamp_list) == 0:
                msg_dict = {}
                msg_dict[GUIServer.WARNING_MESSAGE] = "Octopus Agile rates are published at 16:00 each day. Wait until after this time and try again."
                self._update_gui(msg_dict)
                return None

        else:
            plot_time_stamp_list, plot_cost_list = self._get_tariff_data(end_charge_time)
            if len(plot_time_stamp_list) == 0:
                raise Exception("The ready by time is too soon to charge.")
            end_charge_datetime = plot_time_stamp_list[-1] + timedelta(minutes=30)
            if end_charge_time:
                end_charge_datetime = GUIServer.GET_END_CHARGE_DATETIME(end_charge_time)

        # Check we have enough time to add the required charge
        available_charge_time = end_charge_datetime - plot_time_stamp_list[0]
        available_mins = available_charge_time.total_seconds()/60
        if charge_mins > available_mins:
            ect = end_charge_datetime.strftime("%H:%M on %d %B")
            raise Exception(f"Unable to charge for {charge_mins} minutes before {ect}")

        # Determine the slot duration (30mins ?)
        slot_start_t = plot_time_stamp_list[0]
        slot_end_t = plot_time_stamp_list[1]
        slot_duration = slot_end_t-slot_start_t
        slot_duration_mins = slot_duration.total_seconds()/60.0

        # Update the slots with any free energy periods
        self._update_free_periods(free_start_time_hh_mm, free_duration_hh_mm, plot_time_stamp_list, plot_cost_list)

        time_stamp_list = plot_time_stamp_list
        cost_list = plot_cost_list

        # Pair dates with costs and sort by cost
        sorted_pairs = sorted(zip(cost_list, time_stamp_list))

        # Unzip into separate sorted lists
        sorted_costs, sorted_dates = zip(*sorted_pairs)

        # Convert to lists (optional)
        sorted_costs = list(sorted_costs)
        sorted_dates = list(sorted_dates)

        cost = 0
        total_charge_mins = 0
        charge_slot_dict_list = []
        charge_mins_left = charge_mins
        for index in range(0, len(sorted_costs)):
            if index < len(sorted_dates):
                slot_start_t = sorted_dates[index]
                slot_end_t = slot_start_t+timedelta(minutes=slot_duration_mins)
                # If we need the entire charge slot
                if charge_mins_left >= slot_duration_mins:
                    charge_slot_dict = {}
                    charge_slot_dict[RegionalElectricity.SLOT_START_DATETIME] = slot_start_t
                    charge_slot_dict[RegionalElectricity.SLOT_STOP_DATETIME] = slot_end_t
                    charge_slot_dict[RegionalElectricity.SLOT_COST] = sorted_costs[index]
                    charge_slot_dict_list.append(charge_slot_dict)
                    charge_mins_left = charge_mins_left - slot_duration_mins
                    total_charge_mins = total_charge_mins + slot_duration_mins
                    cost = cost + (((slot_duration_mins/60.0)*charge_rate_kw)*charge_slot_dict[RegionalElectricity.SLOT_COST])

                else:
                    # If we need part of another slot to complete the charge.
                    # The minimum time we will turn the charger on is 15 mins.
                    # This governs the max charge error.
                    if charge_mins_left >= 15:
                        slot_end_t = slot_start_t+timedelta(minutes=charge_mins_left)
                        charge_slot_dict = {}
                        charge_slot_dict[RegionalElectricity.SLOT_START_DATETIME] = slot_start_t
                        charge_slot_dict[RegionalElectricity.SLOT_STOP_DATETIME] = slot_end_t
                        charge_slot_dict[RegionalElectricity.SLOT_COST] = sorted_costs[index]
                        charge_slot_dict_list.append(charge_slot_dict)
                        total_charge_mins = total_charge_mins + charge_mins_left
                        slot_cost = charge_slot_dict[RegionalElectricity.SLOT_COST]
                        cost = cost + (((charge_mins_left/60.0)*charge_rate_kw)*slot_cost)
                        charge_mins_left = 0

                    break

        return (charge_slot_dict_list,
                end_charge_datetime,
                plot_time_stamp_list,
                plot_cost_list,
                total_charge_mins,
                cost)

    def _check_ev_plugged_in(self):
        """@brief Check if EV is plugged in and warn user if not.
           @return True if EV is plugged in to the ZAPPI charger."""
        ev_plugged_in = True
        plug_status = self._my_energi.get_zappi_plug_status()
        self._debug(f"ZAPPI plug_status = {plug_status}")
        if plug_status == MyEnergi.ZAPPI_PST_EV_DISCONNECTED:
            msg_dict = {}
            msg_dict[GUIServer.ERROR_MESSAGE] = "Your EV is not plugged into your ZAPPI charger."
            self._update_gui(msg_dict)
            ev_plugged_in = False

        return ev_plugged_in

    def calc_optimal_charge_times_thread(self,
                                         region_code,
                                         charge_mins,
                                         charge_rate_kw,
                                         end_charge_time,
                                         free_start_time_hh_mm,
                                         free_duration_hh_mm,
                                         octopus_agile_tariff):
        """@brief Calculate optimal charge times.
           @param region_code The regional electricity code.
           @param plot_container The container that will hold the plot.
           @param charge_mins The required charge time in mins.
           @param charge_rate_kw The EV charge rate in kW.
           @param end_charge_time The time (a tuple hours,mins) at which the charging must have completed.
           @param free_start_time_hh_mm A tuple containing HH, MM of the start time of a free energy period or None if no free energy period is available.
           @param free_duration_hh_mm A tuple containing HH, MM of the duration of a free energy period or None if no free energy period is available.
           @param octopus_agile_tariff True if the Octopus Agile tariff is selected.
           @return A dict containing the slots that the car should charge in."""
        try:
            # Check if the EV is plugged in and warn the user but allow them to proceed with calc
            self._check_ev_plugged_in()

            charge_slot_dict_list, end_charge_datetime, plot_time_stamp_list, plot_cost_list, total_charge_mins, cost = self._get_charge_details(charge_mins,
                                                                                                                                                 end_charge_time,
                                                                                                                                                 charge_rate_kw,
                                                                                                                                                 region_code,
                                                                                                                                                 free_start_time_hh_mm,
                                                                                                                                                 free_duration_hh_mm,
                                                                                                                                                 octopus_agile_tariff)

            msg_dict = {}
            msg_dict[GUIServer.PLOT_OPTIMAL_CHARGE_TIMES] = (charge_slot_dict_list, end_charge_datetime, plot_time_stamp_list, plot_cost_list, total_charge_mins, cost)
            self._update_gui(msg_dict)

        except TypeError:
            # We get here if the Octopus Agile tariff values are not available at the moment.
            return

        except Exception as ex:
            GUIServer.Print_Exception()
            # As we've had an error clear any displayed plot before letting the user know
            msg_dict = {}
            msg_dict[GUIServer.CLEAR_PLOT] = ""
            self._update_gui(msg_dict)
            msg_dict = {}
            msg_dict[GUIServer.ERROR_MESSAGE] = str(ex)
            self._update_gui(msg_dict)

    def _plot_optimal_charge_times(self, arg_list):
        """@brief Plot the optimal charge times."""
        # Assign the variables from the arg list
        charge_slot_dict_list, end_charge_datetime, plot_time_stamp_list, plot_cost_list, total_charge_mins, cost = arg_list
        try:
            # Clear the old plot
            self._w._plot_container.clear()

            fig = go.Figure()
            max_cost = max(plot_cost_list)
            min_cost = min(plot_cost_list)
            if min_cost > 0:
                min_cost = 0
            fig.update_layout(margin=dict(l=0, r=0, t=0, b=0),
                              width=350,
                              height=200,
                              showlegend=False,
                              plot_bgcolor="black",       # Background for the plot area
                              paper_bgcolor="black",      # Background for the entire figure
                              font=dict(color="yellow"),   # Font color for labels and title
                              xaxis=dict(
                                  title="",
                                  color="yellow",          # Axis label color
                                  gridcolor="gray",       # Gridline color
                                  zerolinecolor="gray"    # Zero line color
                              ),
                              yaxis=dict(
                                  title="£ per kWh",
                                  color="yellow",         # Axis label color
                                  gridcolor="gray",       # Gridline color
                                  zerolinecolor="gray",   # Zero line color
                                  range=[min_cost*1.5, max_cost*1.5]
                              ),)

            fig.add_trace(go.Bar(x=plot_time_stamp_list, y=plot_cost_list, opacity=0.5, marker=dict(color='green')))

            self._plot_charge_times(fig, charge_slot_dict_list)

            # Add the new plot to the container
            with self._w._plot_container:
                ui.plotly(fig)

            with self._w._plot_container:
                hours_charge_factor = total_charge_mins/60.0
                charge_adjustment_factor = float(self._cmd_line_config_manager.getAttr(GUIServer.ZAPPI_CHARGE_ADJUSTMENT_FACTOR_FLOAT))
                kwh = charge_adjustment_factor * (hours_charge_factor*float(self._w._zappi_max_charge_rate.value))
                self._target_ev_charge_kwh = kwh
                battery_charged_percentage = self._w._target_ev_charge_input.value
                # we may be charging slightly longer than is required (due to 15 min charge increments)
                # so limit the max to 100%
                if battery_charged_percentage > 100.0:
                    battery_charged_percentage = 100.0
                ui.label(f"Charge for {int(total_charge_mins)} minutes to reach {battery_charged_percentage:.0f}%")
                ui.label(f"using {kwh:.1f} kWh of energy (cost = £{cost:.2f}).")

            self._charge_slot_dict_list = charge_slot_dict_list

        except Exception as ex:
            GUIServer.Print_Exception()
            msg_dict = {}
            msg_dict[GUIServer.ERROR_MESSAGE] = str(ex)
            self._update_gui(msg_dict)

    def _plot_charge_times(self, fig, charge_slot_dict_list):
        """@brief Plot the charge times in red on the charge plot.
           @param fig plotly figure as returned from go.Figure()
           @param charge_slot_dict_list"""
        for charge_slot_dict in charge_slot_dict_list:
            startT = charge_slot_dict[RegionalElectricity.SLOT_START_DATETIME]
            stopT = charge_slot_dict[RegionalElectricity.SLOT_STOP_DATETIME]
            x = [startT, stopT]
            y = [charge_slot_dict[RegionalElectricity.SLOT_COST], charge_slot_dict[RegionalElectricity.SLOT_COST]]
            fig.add_trace(go.Scatter(x=x, y=y, line=dict(width=5), marker=dict(size=10, color='red')))

    def _set_zappi_charge(self):
        """@brief Set a zappi charge schedule."""
        if self._charge_slot_dict_list is None:
            ui.notify("No charge schedule found.", type='negative')
        else:
            ui.notify("Setting zappi charge schedule", position='center')
            threading.Thread(target=self._set_zappi_charge_thread).start()
            self._reset_polling_rate()

    def _set_zappi_charge_thread(self):
        # Sort the dicts in the list on the slot start time. The slot closest in time will be first in the list.
        # The zappi charger must be set to eco+ mode to run the charge schedule.
        # Check for this and set if required.
        if not self._check_ev_plugged_in():
            return

        zapp_charge_mode = self._my_energi.get_zappi_charge_mode()
        if zapp_charge_mode != MyEnergi.ZAPPI_CHARGE_MODE_ECO_PLUS:
            self._my_energi.set_zappi_mode_eco_plus()
            # Display a messge to let the user know that the mode had to be set to eco+
            msg_dict = {}
            msg_dict[GUIServer.INFO_MESSAGE] = "Set the zappi to eco+ charge mode."
            self._update_gui(msg_dict)

        sorted_charge_slot_dict_list = sorted(deepcopy(self._charge_slot_dict_list), key=lambda x: x[RegionalElectricity.SLOT_START_DATETIME])

        # merge any consecutive slots together to reduce the number of zappi charge schedules which is limited to 4 on the my energi system.
        index = 0
        merged_charge_slot_dict_list = []
        list_size = len(sorted_charge_slot_dict_list)
        current_slot_start_dict = current_slot_end_dict = None
        for index in range(0, list_size):
            current_slot_dict = sorted_charge_slot_dict_list[index]
            if current_slot_start_dict is None:
                current_slot_start_dict = current_slot_end_dict = current_slot_dict
            # If not on the last slot dict
            if index < list_size-1:
                next_slot_dict = sorted_charge_slot_dict_list[index+1]

                # If the next slot starts when this slot ends
                if current_slot_end_dict[RegionalElectricity.SLOT_STOP_DATETIME] == next_slot_dict[RegionalElectricity.SLOT_START_DATETIME]:
                    current_slot_end_dict = next_slot_dict

                else:
                    current_slot_start_dict[RegionalElectricity.SLOT_STOP_DATETIME] = current_slot_end_dict[RegionalElectricity.SLOT_STOP_DATETIME]
                    merged_charge_slot_dict_list.append(current_slot_start_dict)
                    current_slot_start_dict = current_slot_end_dict = None

            else:
                current_slot_start_dict[RegionalElectricity.SLOT_STOP_DATETIME] = current_slot_end_dict[RegionalElectricity.SLOT_STOP_DATETIME]
                merged_charge_slot_dict_list.append(current_slot_start_dict)

        # A zappi schedule can't be 9 hours or more so split any long merged slots.
        max_slot = timedelta(hours=8, minutes=45)
        split_charge_slot_dict_list = []
        for slot_dict in merged_charge_slot_dict_list:
            start = slot_dict[RegionalElectricity.SLOT_START_DATETIME]
            stop = slot_dict[RegionalElectricity.SLOT_STOP_DATETIME]
            while stop - start > max_slot:
                piece = dict(slot_dict)
                piece[RegionalElectricity.SLOT_START_DATETIME] = start
                piece[RegionalElectricity.SLOT_STOP_DATETIME] = start + max_slot
                split_charge_slot_dict_list.append(piece)
                start = start + max_slot
            piece = dict(slot_dict)
            piece[RegionalElectricity.SLOT_START_DATETIME] = start
            split_charge_slot_dict_list.append(piece)
        merged_charge_slot_dict_list = split_charge_slot_dict_list

        try:
            if len(merged_charge_slot_dict_list) == 0:
                raise Exception("The calculated charge schedule has no duration.")

            self._start_charge_zappi_kwh = self._my_energi.get_zappi_ev_charge_kwh()

            self._my_energi.set_zappi_charge_schedule(merged_charge_slot_dict_list)
            msg_dict = {}
            msg_dict[GUIServer.INFO_MESSAGE] = GUIServer.SET_ZAPPI_CHARGE_SCHEDULE_MESSAGE
            self._update_gui(msg_dict)

            # Get the end of the last charge slot
            charge_end_time = merged_charge_slot_dict_list[-1][RegionalElectricity.SLOT_STOP_DATETIME]
            # Set the delete schedule time to be 10 minutes after the charge finishes. 10 minutes was chosen
            # as I've seen the myenergi system take up to 5 minutes to delete a schedule after sending a
            # successfull command. We want to have it clear before the next 15 minute charge slot.
            clear_schedule_time = charge_end_time + timedelta(minutes=10)
            self._cfg_mgr.addAttr(GUIServer.CLEAR_ZAPPI_SCHEDULE_TIME, clear_schedule_time.strftime("%Y-%m-%dT%H:%M:%SZ"))
            # Save now so the schedule is still cleared if the app restarts before the charge ends.
            self._store_config()

        except Exception as ex:
            GUIServer.Print_Exception()
            msg_dict = {}
            msg_dict[GUIServer.ERROR_MESSAGE] = str(ex)
            self._update_gui(msg_dict)

    def _clear_zappi_charge_schedules(self):
        """@brief Reset/disable all zappi charge schedules.
                  Called from the GUI thread when the user presses the clear schedules button.
                  This starts the thread that actually does the work."""
        ui.notify("Clearing all zappi charge schedules", position='center', type='ongoing', timeout=4500)
        self._w._plot_container.clear()
        self._charge_slot_dict_list = None
        # Reset this so that the Set button returns to it's original color.
        self._zappi_charge_schedule_active = False
        self._w._clear_zappi_button.disable()
        threading.Thread(target=self._clear_zappi_charge_schedules_thread).start()

    def _clear_zappi_charge_schedules_thread(self, send_charged_msg=False):
        """@brief Reset/disable all zappi charge schedules. This must be called outside the GUI thread.
           @param send_charged_msg If True send a charged message to the GUI thread to display a
                  persistent message to the user to show how much charge was added."""
        try:
            self._my_energi.set_all_zappi_schedules_off()
            msg_dict = {}
            msg_dict[GUIServer.INFO_MESSAGE] = GUIServer.CLEARED_ALL_CHARGING_SCHEDULES
            self._update_gui(msg_dict)

            if send_charged_msg:
                # Send a msg to user detailing the charge completed
                msg_dict = {}
                end_charge_zappi_kwh = self._my_energi.get_zappi_ev_charge_kwh()
                self._zappi_charged_kwh = end_charge_zappi_kwh - self._start_charge_zappi_kwh
                msg_dict[GUIServer.ZAPPI_CHARGE_COMPLETE_MESSAGE] = f"EV charge complete. Used {self._zappi_charged_kwh:.2f} kWh. The target was {self._target_ev_charge_kwh:.2f} kWh."
                self._update_gui(msg_dict)

        except Exception as ex:
            GUIServer.Print_Exception()
            msg_dict = {}
            msg_dict[GUIServer.ERROR_MESSAGE] = str(ex)
            self._update_gui(msg_dict)

    # ------------------------------------------------------------------------------------------
    # Tank temperature recording and plotting
    # ------------------------------------------------------------------------------------------

    def _get_cmd_line_int(self, key, default):
        """@brief Get an int from the command line config, falling back to a default if invalid.
           @param key The config key.
           @param default The value to use if the config value is missing or invalid."""
        try:
            return int(self._cmd_line_config_manager.getAttr(key))
        except Exception:
            return default

    def _start_background_threads(self):
        """@brief Start the threads that run whether or not a browser is connected.
                  - The tank temperature recorder.
                  - Housekeeping (removes finished eddi/zappi schedules)."""
        if not self._background_threads:
            self._background_stop_event.clear()
            for target in (self._tank_temp_recorder_thread, self._housekeeping_thread):
                thread = threading.Thread(target=target, daemon=True)
                thread.start()
                self._background_threads.append(thread)

    def _stop_background_threads(self):
        """@brief Stop the background threads."""
        self._background_stop_event.set()

    def _tank_temp_recorder_thread(self):
        """@brief Periodically read the tank temperatures from the myenergi server and record them."""
        interval = self._get_cmd_line_int(GUIServer.TANK_TEMP_RECORD_SECONDS_INT, GUIServer.DEFAULT_TANK_TEMP_RECORD_SECONDS)
        self._info(f"Recording tank temperatures every {interval} seconds.")
        while not self._background_stop_event.is_set():
            try:
                if self._is_eddi_config_entered():
                    # Take a local reference as the MyEnergi instance is replaced if the user saves the settings.
                    my_energi = self._my_energi
                    my_energi.update_stats()
                    top_temp = my_energi.get_eddi_top_tank_temp()
                    bottom_temp = my_energi.get_eddi_bottom_tank_temp()
                    # Don't lose the temperatures if the heater stats are missing.
                    try:
                        heater_w = my_energi.get_eddi_heater_watts()
                        heater_no = my_energi.get_eddi_heater_number()
                    except Exception:
                        heater_w = heater_no = None
                    self._tank_temp_history.add(top_temp, bottom_temp, heater_w, heater_no)
                    self._debug(f"Recorded tank: top={top_temp} °C, bottom={bottom_temp} °C, heater={heater_no} {heater_w} W")
            except Exception as ex:
                # Network issues are expected occasionally. Log and carry on, don't bother the GUI user.
                self._error(f"Failed to record tank temperatures: {str(ex)}")
            self._background_stop_event.wait(interval)

    def _init_temps_tab(self):
        """@brief Init the tab used to display the tank temperature history."""
        with ui.row().classes('w-full items-center'):
            self._w._temp_period_select = ui.select(options=list(GUIServer.TEMP_PLOT_PERIODS.keys()),
                                                    value=GUIServer.DEFAULT_TEMP_PLOT_PERIOD,
                                                    label='Period',
                                                    on_change=self._plot_tank_temps).style("width: 150px; " + GUIServer.TEXT_STYLE_A_SIZE)
            ColorButton(self._plot_tank_temps, 'Refresh').tooltip("Update the tank temperature plot.")
            ColorButton(self._clear_tank_temp_history, 'Clear').tooltip("Delete all recorded tank temperatures.")
            self._w._heater_shade_checkbox = ui.checkbox('Heater', value=True, on_change=self._plot_tank_temps)
            self._w._heater_shade_checkbox.tooltip("Shade when the immersion heaters were on. Upper half = top heater, lower half = bottom heater. "
                                                   "Yellow = solar, green = mains.")

        with ui.row():
            self._w._temp_plot_container = ui.element('div')

        self._plot_tank_temps()
        # Keep the plot up to date while the page is open.
        ui.timer(interval=GUIServer.TEMP_PLOT_AUTO_REFRESH_SECONDS, callback=self._plot_tank_temps)

    def _clear_tank_temp_history(self):
        """@brief Ask the user to confirm before deleting the tank temperature history."""
        with ui.dialog() as dialog, ui.card():
            ui.label("Delete all recorded tank temperatures ?")
            with ui.row().classes('w-full justify-center'):
                ui.button('Yes', color=GUIServer.DEFAULT_BUTTON_COLOR, on_click=lambda: (self._tank_temp_history.clear(),
                                                                                         dialog.close(),
                                                                                         self._plot_tank_temps(),
                                                                                         ui.notify("Tank temperature history deleted.")))
                ui.button('No', color=GUIServer.DEFAULT_BUTTON_COLOR, on_click=dialog.close)
        dialog.open()

    def _get_heater_runs(self, samples):
        """@brief Convert the recorded samples into periods when an immersion heater was on.
                  Consecutive samples with the same heater and power source are merged into one period.
           @param samples A list of samples as returned by TankTempHistory.get().
           @return A list of (start datetime, stop datetime, heater number, heater source) tuples."""
        record_seconds = self._get_cmd_line_int(GUIServer.TANK_TEMP_RECORD_SECONDS_INT, GUIServer.DEFAULT_TANK_TEMP_RECORD_SECONDS)
        sample_period = timedelta(seconds=record_seconds)
        # If the gap to the next sample is larger than this the recorder was not running,
        # so assume the heater state only lasted for one sample period.
        max_gap = sample_period * 3

        runs = []
        current = None      # [start, stop, heater_no, source]
        for index, sample in enumerate(samples):
            ts, _, _, heater_w, heater_no = sample
            source = GUIServer.GET_HEATER_SOURCE(heater_w)
            heater_on = source != GUIServer.HEATER_SOURCE_NONE and heater_no in (MyEnergi.TANK_TOP, MyEnergi.TANK_BOTTOM)

            # The state seen at this sample is assumed to last until the next sample.
            if index < len(samples) - 1 and samples[index + 1][0] - ts <= max_gap:
                stop = samples[index + 1][0]
            else:
                stop = ts + sample_period

            if heater_on:
                if current and current[2] == heater_no and current[3] == source and current[1] >= ts:
                    current[1] = stop
                else:
                    if current:
                        runs.append(tuple(current))
                    current = [ts, stop, heater_no, source]
            elif current:
                runs.append(tuple(current))
                current = None

        if current:
            runs.append(tuple(current))
        return runs

    def _plot_tank_temps(self):
        """@brief Plot the recorded top and bottom tank temperatures, shading the periods
                  when each immersion heater was on and whether it was powered by solar or mains."""
        if self._w._temp_plot_container is None or self._w._temp_period_select is None:
            return
        try:
            hours = GUIServer.TEMP_PLOT_PERIODS.get(self._w._temp_period_select.value, 24)
            samples = self._tank_temp_history.get(hours)
            self._w._temp_plot_container.clear()
            with self._w._temp_plot_container:
                if len(samples) == 0:
                    ui.label("No tank temperatures recorded yet.").style(GUIServer.TEXT_STYLE_C)
                    return

                ts_list = [s[0] for s in samples]
                top_list = [s[1] for s in samples]
                bottom_list = [s[2] for s in samples]

                # Show HH:MM for short periods and the day as well for longer ones.
                tick_format = '%H:%M' if hours <= 24 else '%a %H:%M'
                all_temps = top_list + bottom_list
                y_min = max(0, min(all_temps) - 5)
                y_max = max(all_temps) + 5

                fig = go.Figure()
                fig.update_layout(margin=dict(l=0, r=0, t=0, b=0),
                                  width=350,
                                  height=250,
                                  showlegend=True,
                                  legend=dict(orientation="h", yanchor="bottom", y=1.0, xanchor="left", x=0),
                                  plot_bgcolor="black",
                                  paper_bgcolor="black",
                                  font=dict(color="yellow"),
                                  xaxis=dict(
                                      title="",
                                      tickformat=tick_format,
                                      color="yellow",
                                      gridcolor="gray",
                                      zerolinecolor="gray"
                                  ),
                                  yaxis=dict(
                                      title="°C",
                                      color="yellow",
                                      gridcolor="gray",
                                      zerolinecolor="gray",
                                      range=[y_min, y_max]
                                  ),)

                heater_on_mins = {GUIServer.HEATER_SOURCE_SOLAR: 0.0, GUIServer.HEATER_SOURCE_MAINS: 0.0}
                if self._w._heater_shade_checkbox is None or self._w._heater_shade_checkbox.value:
                    for start, stop, heater_no, source in self._get_heater_runs(samples):
                        # Top heater shades the upper half of the plot, bottom heater the lower half.
                        y0, y1 = (0.5, 1.0) if heater_no == MyEnergi.TANK_TOP else (0.0, 0.5)
                        fig.add_shape(type="rect",
                                      xref="x", yref="y domain",
                                      x0=start, x1=stop, y0=y0, y1=y1,
                                      fillcolor=GUIServer.HEATER_SHADE_COLORS[source],
                                      opacity=GUIServer.HEATER_SHADE_OPACITY,
                                      line_width=0,
                                      layer="below")
                        heater_on_mins[source] += (stop - start).total_seconds() / 60.0

                fig.add_trace(go.Scatter(x=ts_list, y=top_list, mode='lines', name='Top', line=dict(color='orangered', width=2)))
                fig.add_trace(go.Scatter(x=ts_list, y=bottom_list, mode='lines', name='Bottom', line=dict(color='deepskyblue', width=2)))
                ui.plotly(fig)
                ui.label(f"Now: top {top_list[-1]:.0f} °C, bottom {bottom_list[-1]:.0f} °C "
                         f"(at {ts_list[-1].strftime('%H:%M')})").style(GUIServer.TEXT_STYLE_C)
                if self._w._heater_shade_checkbox is None or self._w._heater_shade_checkbox.value:
                    solar = heater_on_mins[GUIServer.HEATER_SOURCE_SOLAR]
                    mains = heater_on_mins[GUIServer.HEATER_SOURCE_MAINS]
                    ui.label(f"Heater on: solar {solar/60:.1f} h, mains {mains/60:.1f} h").style(GUIServer.TEXT_STYLE_C)

        except Exception as ex:
            GUIServer.Print_Exception()
            ui.notify(f"{str(ex)}", type='negative')

    def command_line_config(self):
        """@brief Allow the user to configure the command line parameters."""
        self._cmd_line_config_manager.edit(GUIServer.CMD_LINE_CONFIG_ATTR_DICT)


def main():
    """@brief Program entry point"""
    uio = UIO()
    options = None

    try:
        parser = argparse.ArgumentParser(description="A program that provides a display interface for myenergi products.",
                                         formatter_class=argparse.RawDescriptionHelpFormatter)
        parser.add_argument("-p", "--port",    type=int, help=f"The TCP server port to which the GUI server is bound to (default={GUIServer.DEFAULT_SERVER_PORT}).", default=GUIServer.DEFAULT_SERVER_PORT)
        parser.add_argument("-c", "--config",  action='store_true', help="Command line configuration.")
        parser.add_argument("--reload",        action='store_true', help="Reload/Restart GUI when python file is updated. Useful for in dev env.")
        parser.add_argument("--show",          action='store_true', help="Show the GUI (open browser window) on startup.")
        parser.add_argument("-d", "--debug",   action='store_true', help="Enable debugging of the myenergi_display program.")
        parser.add_argument("--nicegui_debug", action='store_true', help="Enable debugging of the nicegui python module.")
        parser.add_argument("-s", "--syslog",  action='store_true', help="Enable syslog.")
        BootManager.AddCmdArgs(parser)

        options = parser.parse_args()
        uio.enableDebug(options.debug)
        uio.logAll(True)
        uio.enableSyslog(options.syslog, programName="ngt")
        if options.syslog:
            uio.info("Syslog enabled")

        handled = BootManager.HandleOptions(uio, options, options.syslog)
        if not handled:
            gui = GUIServer(uio, options.port)
            if options.config:
                gui.command_line_config()

            else:

                gui.create_gui(options.nicegui_debug,
                               reload=options.reload,
                               show=options.show)

    # If the program throws a system exit exception
    except SystemExit:
        pass
    # Don't print error information if CTRL C pressed
    except KeyboardInterrupt:
        pass
    except Exception as ex:
        logTraceBack(uio)

        if not options or options.debug:
            raise
        else:
            uio.error(str(ex))


# Note __mp_main__ is used by the nicegui module
if __name__ in {"__main__", "__mp_main__"}:
    main()
